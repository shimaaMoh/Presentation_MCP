/**
 * Google Cloud Storage (GCS) Uploader & V4 Signed URL Generator for RCMC Presentation MCP Server.
 * Uses native Node.js HTTPS and GCP Compute Metadata Server / IAM Credentials API for zero-dependency operation.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const GCS_BUCKET = (process.env.GCS_BUCKET || 'rcmc-prod-gemini-enterprise-01-staging-bucket')
  .replace(/^gs:\/\//, '')
  .replace(/\/+$/, '')
  .trim();

const FALLBACK_BUCKETS = [
  'rcmc-prod-gemini-enterprise-01-staging-bucket',
  'cmc-prod-gemini-enterprise-01-staging-bucket'
];

const METADATA_TOKEN_URL = 'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token';
const METADATA_EMAIL_URL = 'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email';
const DEFAULT_SERVICE_ACCOUNT = '76908917879-compute@developer.gserviceaccount.com';

let cachedToken = null;
let tokenExpiresAt = 0;
let cachedEmail = null;

/**
 * Fetch OAuth2 Bearer token from GCP Cloud Run metadata server.
 */
function getGcpAccessToken() {
  return new Promise((resolve) => {
    if (cachedToken && Date.now() < tokenExpiresAt) {
      return resolve(cachedToken);
    }

    const req = http.get(
      METADATA_TOKEN_URL,
      {
        headers: { 'Metadata-Flavor': 'Google' },
        timeout: 2500
      },
      (res) => {
        if (res.statusCode !== 200) {
          resolve(null);
          return;
        }
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            if (parsed.access_token) {
              cachedToken = parsed.access_token;
              tokenExpiresAt = Date.now() + Math.max(60, (parsed.expires_in || 3600) - 60) * 1000;
              resolve(cachedToken);
            } else {
              resolve(null);
            }
          } catch (e) {
            resolve(null);
          }
        });
      }
    );

    req.on('error', () => resolve(null));
    req.on('timeout', () => {
      req.destroy();
      resolve(null);
    });
  });
}

/**
 * Fetch Service Account email from GCP Cloud Run metadata server.
 */
function getGcpServiceAccountEmail() {
  return new Promise((resolve) => {
    if (cachedEmail) return resolve(cachedEmail);
    if (process.env.GCP_SERVICE_ACCOUNT) {
      cachedEmail = process.env.GCP_SERVICE_ACCOUNT.trim();
      return resolve(cachedEmail);
    }

    const req = http.get(
      METADATA_EMAIL_URL,
      {
        headers: { 'Metadata-Flavor': 'Google' },
        timeout: 2000
      },
      (res) => {
        if (res.statusCode !== 200) {
          resolve(DEFAULT_SERVICE_ACCOUNT);
          return;
        }
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          const email = (data || '').trim();
          cachedEmail = email || DEFAULT_SERVICE_ACCOUNT;
          resolve(cachedEmail);
        });
      }
    );

    req.on('error', () => resolve(DEFAULT_SERVICE_ACCOUNT));
    req.on('timeout', () => {
      req.destroy();
      resolve(DEFAULT_SERVICE_ACCOUNT);
    });
  });
}

/**
 * Digitally sign a blob using Google Cloud IAM Credentials API (signBlob).
 * Requires roles/iam.serviceAccountTokenCreator on the calling service account.
 */
function signBlobWithIam(serviceAccount, token, stringToSign) {
  return new Promise((resolve) => {
    const postData = JSON.stringify({
      payload: Buffer.from(stringToSign, 'utf8').toString('base64')
    });
    const url = `https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/${encodeURIComponent(serviceAccount)}:signBlob`;
    const parsedUrl = new URL(url);

    const req = https.request(
      parsedUrl,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json; charset=UTF-8',
          'Content-Length': String(Buffer.byteLength(postData))
        },
        timeout: 6000
      },
      (res) => {
        let resData = '';
        res.on('data', (c) => { resData += c; });
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            try {
              const parsed = JSON.parse(resData);
              if (parsed.signedBlob) {
                const sigHex = Buffer.from(parsed.signedBlob, 'base64').toString('hex');
                return resolve(sigHex);
              }
            } catch (e) {
              console.error('[signBlob Parse Error]:', e.message);
            }
          }
          console.error(`[signBlob HTTP ${res.statusCode} Error]:`, resData);
          resolve(null);
        });
      }
    );

    req.on('error', (err) => {
      console.error('[signBlob Request Error]:', err.message);
      resolve(null);
    });
    req.on('timeout', () => {
      req.destroy();
      console.error('[signBlob Timeout]');
      resolve(null);
    });

    req.write(postData);
    req.end();
  });
}

/**
 * Generates a standard Google Cloud Storage V4 Signed URL for GET operations.
 * Works with zero private keys on Cloud Run via IAM Credentials API.
 */
async function generateV4SignedUrl(bucket, objectName, token, expiresInSeconds = 1800) {
  try {
    if (!token) return null;
    const serviceAccount = await getGcpServiceAccountEmail();

    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const dateStamp = '' + now.getUTCFullYear() + pad(now.getUTCMonth() + 1) + pad(now.getUTCDate());
    const timestamp = dateStamp + 'T' + pad(now.getUTCHours()) + pad(now.getUTCMinutes()) + pad(now.getUTCSeconds()) + 'Z';
    const credentialScope = `${dateStamp}/auto/storage/goog4_request`;
    const credential = `${serviceAccount}/${credentialScope}`;

    const encodedPath = objectName.split('/').map(encodeURIComponent).join('/');
    const canonicalUri = `/${encodeURIComponent(bucket)}/${encodedPath}`;

    const queryParams = [
      ['X-Goog-Algorithm', 'GOOG4-RSA-SHA256'],
      ['X-Goog-Credential', credential],
      ['X-Goog-Date', timestamp],
      ['X-Goog-Expires', String(expiresInSeconds)],
      ['X-Goog-SignedHeaders', 'host']
    ];
    queryParams.sort((a, b) => a[0].localeCompare(b[0]));
    const canonicalQueryString = queryParams
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
      .join('&');

    const canonicalHeaders = 'host:storage.googleapis.com\n';
    const signedHeaders = 'host';
    const hashedPayload = 'UNSIGNED-PAYLOAD';

    const canonicalRequest = [
      'GET',
      canonicalUri,
      canonicalQueryString,
      canonicalHeaders,
      signedHeaders,
      hashedPayload
    ].join('\n');

    const stringToSign = [
      'GOOG4-RSA-SHA256',
      timestamp,
      credentialScope,
      crypto.createHash('sha256').update(canonicalRequest, 'utf8').digest('hex')
    ].join('\n');

    const signature = await signBlobWithIam(serviceAccount, token, stringToSign);
    if (!signature) {
      console.warn('[V4 Signed URL] Failed to generate signature, will fallback to direct authenticated URL');
      return null;
    }

    const signedUrl = `https://storage.googleapis.com/${encodeURIComponent(bucket)}/${encodedPath}?${canonicalQueryString}&X-Goog-Signature=${signature}`;
    return signedUrl;
  } catch (err) {
    console.error('[generateV4SignedUrl Exception]:', err.message);
    return null;
  }
}

function performSingleBucketUpload(bodyBuffer, boundary, token, bucket, objectName) {
  const uploadUrl = `https://storage.googleapis.com/upload/storage/v1/b/${encodeURIComponent(bucket)}/o?uploadType=multipart`;
  return new Promise((resolve) => {
    const parsedUrl = new URL(uploadUrl);
    const req = https.request(
      parsedUrl,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
          'Content-Length': String(bodyBuffer.length)
        },
        timeout: 30000
      },
      async (res) => {
        let resData = '';
        res.on('data', (c) => { resData += c; });
        res.on('end', async () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            // Generate V4 Signed URL (valid for 30 minutes / 1800s)
            const signedUrl = await generateV4SignedUrl(bucket, objectName, token, 1800);
            const fallbackGcsUrl = `https://storage.cloud.google.com/${bucket}/${objectName}`;
            const finalUrl = signedUrl || fallbackGcsUrl;

            resolve({
              success: true,
              bucket,
              object_name: objectName,
              gcs_url: finalUrl,
              signed_url: signedUrl,
              direct_url: fallbackGcsUrl,
              gs_uri: `gs://${bucket}/${objectName}`
            });
          } else {
            resolve({ success: false, statusCode: res.statusCode, error: resData });
          }
        });
      }
    );

    req.on('error', (err) => {
      resolve({ success: false, error: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ success: false, error: 'Upload timed out' });
    });

    req.write(bodyBuffer);
    req.end();
  });
}

/**
 * Upload a local file to GCS bucket using standard multipart upload.
 * Sets Content-Disposition to attachment (for downloads) or inline (for web viewing).
 */
async function uploadToGcs(localFilePath, objectName, contentType, downloadFilename, bucket = GCS_BUCKET, dispositionType = 'attachment') {
  try {
    if (!fs.existsSync(localFilePath)) {
      return { success: false, error: `File not found: ${localFilePath}` };
    }

    const token = await getGcpAccessToken();
    if (!token) {
      return { success: false, reason: 'No GCP metadata token available (local dev or unauthenticated)' };
    }

    const fileBuffer = fs.readFileSync(localFilePath);
    const boundary = `----GCSBoundary${Date.now().toString(16)}`;

    const metadata = {
      name: objectName,
      contentType: contentType,
      contentDisposition: dispositionType === 'inline' ? 'inline' : `attachment; filename="${downloadFilename || path.basename(localFilePath)}"`,
      cacheControl: 'public, max-age=86400'
    };

    const metadataPart = [
      `--${boundary}\r\n`,
      'Content-Type: application/json; charset=UTF-8\r\n\r\n',
      JSON.stringify(metadata),
      '\r\n'
    ].join('');

    const mediaHeader = [
      `--${boundary}\r\n`,
      `Content-Type: ${contentType}\r\n\r\n`
    ].join('');

    const mediaFooter = `\r\n--${boundary}--\r\n`;

    const bodyBuffer = Buffer.concat([
      Buffer.from(metadataPart, 'utf8'),
      Buffer.from(mediaHeader, 'utf8'),
      fileBuffer,
      Buffer.from(mediaFooter, 'utf8')
    ]);

    const candidates = [bucket, ...FALLBACK_BUCKETS.filter((b) => b !== bucket)];
    let lastRes = null;

    for (const candidateBucket of candidates) {
      const res = await performSingleBucketUpload(bodyBuffer, boundary, token, candidateBucket, objectName);
      if (res.success) {
        return res;
      }
      lastRes = res;
      if (res.statusCode !== 404) {
        break;
      }
    }

    console.error(`[GCS Upload Error] HTTP ${lastRes && lastRes.statusCode}: ${lastRes && lastRes.error}`);
    return lastRes || { success: false, error: 'Upload failed' };
  } catch (err) {
    console.error(`[GCS Upload Exception]: ${err.message}`);
    return { success: false, error: err.message };
  }
}

module.exports = {
  GCS_BUCKET,
  getGcpAccessToken,
  getGcpServiceAccountEmail,
  generateV4SignedUrl,
  uploadToGcs
};
