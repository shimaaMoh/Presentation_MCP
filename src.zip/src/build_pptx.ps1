param(
    [Parameter(Mandatory=$true)][string]$SpecFile
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Xml

$rootDir = Split-Path -Parent $PSScriptRoot
$specJson = Get-Content -Path $SpecFile -Raw -Encoding UTF8 | ConvertFrom-Json
$catalogJson = Get-Content -Path (Join-Path $PSScriptRoot "catalog.json") -Raw -Encoding UTF8 | ConvertFrom-Json

$lang = if ($specJson.language -and $specJson.language.ToUpper() -eq "EN") { "EN" } else { "AR" }
$masterPath = [System.IO.Path]::Combine($rootDir, "assets", "templates", "RCMC_Master_${lang}_Optimized.pptx")
$outPptxPath = $specJson.output_pptx

# Ensure output directory exists
$outDir = Split-Path -Parent $outPptxPath
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }

Copy-Item -Force $masterPath $outPptxPath

# Build lookup maps from catalog
$layoutMap = @{}
foreach ($l in $catalogJson.layouts) { $layoutMap[$l.id] = $l }
$photoMap = @{}
foreach ($p in $catalogJson.photos) { $photoMap[$p.id] = $p }

# Helper to set text inside a shape (<p:sp>) by its cNvPr id
function Set-ShapeText([xml]$xmlDoc, [string]$shapeId, [string]$newText) {
    if ($null -eq $newText) { return }
    $sp = $xmlDoc.SelectSingleNode("//*[local-name()='sp'][*[local-name()='nvSpPr']/*[local-name()='cNvPr' and @id='$shapeId']]")
    if (-not $sp) { return }
    $txBody = $sp.SelectSingleNode("./*[local-name()='txBody']")
    if (-not $txBody) { return }
    $paras = @($txBody.SelectNodes("./*[local-name()='p']"))
    if ($paras.Count -eq 0) { return }

    # Split newText by newline if multi-paragraph
    $lines = $newText -split "`r?`n"
    $firstPara = $paras[0]
    
    # Remove extra paragraphs beyond the first
    for ($i = 1; $i -lt $paras.Count; $i++) {
        [void]$txBody.RemoveChild($paras[$i])
    }

    for ($li = 0; $li -lt $lines.Count; $li++) {
        $pNode = if ($li -eq 0) { $firstPara } else {
            $cloned = $firstPara.CloneNode($true)
            [void]$txBody.AppendChild($cloned)
            $cloned
        }
        $runs = @($pNode.SelectNodes("./*[local-name()='r']"))
        if ($runs.Count -gt 0) {
            $firstRun = $runs[0]
            for ($ri = 1; $ri -lt $runs.Count; $ri++) {
                [void]$pNode.RemoveChild($runs[$ri])
            }
            $tNode = $firstRun.SelectSingleNode("./*[local-name()='t']")
            if ($tNode) {
                $tNode.InnerText = $lines[$li]
            }
        } else {
            # Create an a:r and a:t if empty placeholder
            $aNs = "http://schemas.openxmlformats.org/drawingml/2006/main"
            $rElem = $xmlDoc.CreateElement("a", "r", $aNs)
            $tElem = $xmlDoc.CreateElement("a", "t", $aNs)
            $tElem.InnerText = $lines[$li]
            [void]$rElem.AppendChild($tElem)
            [void]$pNode.AppendChild($rElem)
        }
    }
}

# Helper to swap photo target in slide rels
function Set-SlidePhoto([xml]$slideXml, [xml]$relsXml, [string]$picShapeId, [string]$photoId, [string]$lang) {
    if (-not $photoId -or -not $photoMap.ContainsKey($photoId)) { return }
    $pEntry = $photoMap[$photoId]
    $mediaFile = if ($lang -eq "AR") { $pEntry.ar_media } else { $pEntry.en_media }
    if (-not $mediaFile) { return }

    $pic = $slideXml.SelectSingleNode("//*[local-name()='pic'][*[local-name()='nvPicPr']/*[local-name()='cNvPr' and @id='$picShapeId']]")
    if (-not $pic) { return }
    $blip = $pic.SelectSingleNode(".//*[local-name()='blip']")
    if (-not $blip) { return }
    $rId = $blip.GetAttribute("embed", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")
    if (-not $rId) { $rId = $blip.embed }
    if (-not $rId) { return }

    $rel = $relsXml.SelectSingleNode("//*[local-name()='Relationship' and @Id='$rId']")
    if ($rel) {
        $rel.SetAttribute("Target", "../media/$mediaFile")
    }
}

# Helper to populate table on data_table_slide
function Set-SlideTable([xml]$slideXml, $headers, $rowsData) {
    $tbl = $slideXml.SelectSingleNode("//*[local-name()='tbl']")
    if (-not $tbl) { return }
    $trList = @($tbl.SelectNodes("./*[local-name()='tr']"))
    if ($trList.Count -eq 0) { return }

    # Combine headers + rowsData
    $allRows = @()
    if ($headers -and $headers.Count -gt 0) { $allRows += ,$headers }
    if ($rowsData) {
        foreach ($r in $rowsData) { $allRows += ,$r }
    }
    if ($allRows.Count -eq 0) { return }

    for ($rIdx = 0; $rIdx -lt $trList.Count; $rIdx++) {
        $tr = $trList[$rIdx]
        if ($rIdx -ge $allRows.Count) {
            [void]$tbl.RemoveChild($tr)
            continue
        }
        $rowVals = @($allRows[$rIdx])
        $tcList = @($tr.SelectNodes("./*[local-name()='tc']"))
        for ($cIdx = 0; $cIdx -lt $tcList.Count; $cIdx++) {
            $tc = $tcList[$cIdx]
            $val = if ($cIdx -lt $rowVals.Count) { [string]$rowVals[$cIdx] } else { "" }
            $tNodes = @($tc.SelectNodes(".//*[local-name()='t']"))
            if ($tNodes.Count -gt 0) {
                $tNodes[0].InnerText = $val
                for ($ti = 1; $ti -lt $tNodes.Count; $ti++) { $tNodes[$ti].InnerText = "" }
            }
        }
    }
}

# Apply slide content mapping based on layout_id and language
function Populate-Slide([xml]$sXml, [xml]$rXml, $slideSpec, [int]$slideNumber, [string]$lang) {
    $lid = $slideSpec.layout_id
    $title = [string]$slideSpec.title
    $subtitle = [string]$slideSpec.subtitle
    $heading = [string]$slideSpec.heading
    $body = [string]$slideSpec.body
    $dept = [string]$slideSpec.department
    $date = [string]$slideSpec.date
    $conf = [string]$slideSpec.confidentiality
    $photoId = [string]$slideSpec.photo_id
    $items = @($slideSpec.items)
    $metrics = @($slideSpec.metrics)

    # Update slide number shapes if present
    Set-ShapeText $sXml "16" "$slideNumber"
    Set-ShapeText $sXml "53" "$slideNumber"
    Set-ShapeText $sXml "19" "$slideNumber"
    Set-ShapeText $sXml "35" "$slideNumber"
    Set-ShapeText $sXml "42" "$slideNumber"

    if ($lang -eq "AR") {
        switch ($lid) {
            "cover_green_arch" {
                Set-ShapeText $sXml "7" $title
                Set-ShapeText $sXml "8" $subtitle
                if ($dept) { Set-ShapeText $sXml "4" $dept }
                if ($date) { Set-ShapeText $sXml "5" $date }
                if ($conf) { Set-ShapeText $sXml "6" $conf }
            }
            "cover_photo_arch" {
                Set-ShapeText $sXml "5" $title
                Set-ShapeText $sXml "7" $subtitle
                Set-SlidePhoto $sXml $rXml "2" $photoId $lang
            }
            "cover_split_photo" {
                Set-ShapeText $sXml "6" $title
                Set-ShapeText $sXml "10" $subtitle
                if ($dept) { Set-ShapeText $sXml "7" $dept }
                if ($date) { Set-ShapeText $sXml "8" $date }
                if ($conf) { Set-ShapeText $sXml "9" $conf }
                Set-SlidePhoto $sXml $rXml "11" $photoId $lang
            }
            "section_emerald" {
                Set-ShapeText $sXml "4" $title
                Set-ShapeText $sXml "5" $subtitle
            }
            "section_sand_gold" {
                Set-ShapeText $sXml "4" $title
                Set-ShapeText $sXml "5" $subtitle
            }
            "section_photo_banner" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                Set-SlidePhoto $sXml $rXml "6" $photoId $lang
            }
            "content_split_photo" {
                Set-ShapeText $sXml "17" $title
                Set-ShapeText $sXml "16" $subtitle
                Set-ShapeText $sXml "18" $heading
                Set-ShapeText $sXml "19" $body
                Set-SlidePhoto $sXml $rXml "20" $photoId $lang
            }
            "content_two_photos" {
                Set-ShapeText $sXml "16" $title
                Set-ShapeText $sXml "15" $subtitle
                Set-ShapeText $sXml "17" $heading
                Set-ShapeText $sXml "18" $body
                Set-SlidePhoto $sXml $rXml "13" $photoId $lang
            }
            "three_pillars_icons" {
                Set-ShapeText $sXml "3" $title
                Set-ShapeText $sXml "2" $subtitle
                $hIds = @("29", "58", "63")
                $bIds = @("28", "57", "62")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "three_cards_with_photo" {
                Set-ShapeText $sXml "6" $title
                Set-ShapeText $sXml "5" $subtitle
                Set-SlidePhoto $sXml $rXml "83" $photoId $lang
                $hIds = @("58", "78", "82")
                $bIds = @("70", "76", "80")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "agenda_four_items" {
                Set-ShapeText $sXml "27" $title
                Set-ShapeText $sXml "26" $subtitle
                Set-SlidePhoto $sXml $rXml "84" $photoId $lang
                $nIds = @("90", "4", "7", "10")
                $hIds = @("87", "2", "5", "8")
                $bIds = @("88", "3", "6", "9")
                for ($i=0; $i -lt [math]::Min(4, $items.Count); $i++) {
                    if ($items[$i].number) { Set-ShapeText $sXml $nIds[$i] ([string]$items[$i].number) }
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "three_rows_icons_photo" {
                Set-ShapeText $sXml "19" $title
                Set-ShapeText $sXml "18" $subtitle
                Set-SlidePhoto $sXml $rXml "91" $photoId $lang
                $hIds = @("15", "21", "23")
                $bIds = @("17", "20", "22")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "highlight_banner_photo" {
                Set-ShapeText $sXml "9" $title
                Set-ShapeText $sXml "8" $subtitle
                Set-ShapeText $sXml "10" $heading
                Set-ShapeText $sXml "11" $body
                Set-SlidePhoto $sXml $rXml "93" $photoId $lang
            }
            "kpi_metrics_chart" {
                Set-ShapeText $sXml "6" $title
                Set-ShapeText $sXml "5" $subtitle
                $vIds = @("12", "13", "14")
                $dIds = @("15", "17", "18")
                $srcList = if ($metrics.Count -gt 0) { $metrics } else { $items }
                for ($i=0; $i -lt [math]::Min(3, $srcList.Count); $i++) {
                    $val = if ($srcList[$i].value) { $srcList[$i].value } else { $srcList[$i].heading }
                    $desc = if ($srcList[$i].description) { $srcList[$i].description } else { $srcList[$i].body }
                    Set-ShapeText $sXml $vIds[$i] ([string]$val)
                    Set-ShapeText $sXml $dIds[$i] ([string]$desc)
                }
            }
            "timeline_three_horizons" {
                Set-ShapeText $sXml "5" $title
                Set-ShapeText $sXml "4" $subtitle
                $hIds = @("94", "95", "96")
                $dIds = @("98", "99", "100")
                $bIds = @("103", "104", "105")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    $hor = if ($items[$i].horizon) { $items[$i].horizon } else { $items[$i].heading }
                    $dur = if ($items[$i].duration) { $items[$i].duration } else { $items[$i].number }
                    if ($hor) { Set-ShapeText $sXml $hIds[$i] ([string]$hor) }
                    if ($dur) { Set-ShapeText $sXml $dIds[$i] ([string]$dur) }
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "four_grid_infographic" {
                Set-ShapeText $sXml "24" $title
                Set-ShapeText $sXml "25" $subtitle
                $nIds = @("27", "30", "33", "36")
                $hIds = @("26", "29", "32", "35")
                $bIds = @("28", "31", "34", "37")
                for ($i=0; $i -lt [math]::Min(4, $items.Count); $i++) {
                    if ($items[$i].number) { Set-ShapeText $sXml $nIds[$i] ([string]$items[$i].number) }
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "process_four_stages" {
                Set-ShapeText $sXml "5" $title
                Set-ShapeText $sXml "4" $subtitle
                $sIds = @("112", "113", "111", "110")
                $bIds = @("103", "130", "131", "132")
                for ($i=0; $i -lt [math]::Min(4, $items.Count); $i++) {
                    $stName = if ($items[$i].stage_name) { $items[$i].stage_name } else { $items[$i].heading }
                    if ($stName) { Set-ShapeText $sXml $sIds[$i] ([string]$stName) }
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "data_table_slide" {
                Set-ShapeText $sXml "22" $title
                Set-ShapeText $sXml "21" $subtitle
                Set-ShapeText $sXml "23" $heading
                Set-ShapeText $sXml "24" $body
                Set-SlideTable $sXml $slideSpec.table_headers $slideSpec.table_rows
            }
            "closing_thank_you" {
                if ($title) { Set-ShapeText $sXml "2" $title }
            }
        }
    } else {
        # ENGLISH MAPPINGS
        switch ($lid) {
            "cover_green_arch" {
                Set-ShapeText $sXml "7" $title
                Set-ShapeText $sXml "8" $subtitle
                if ($dept) { Set-ShapeText $sXml "2" $dept }
                if ($date) { Set-ShapeText $sXml "5" $date }
            }
            "cover_photo_arch" {
                Set-ShapeText $sXml "3" $title
                Set-ShapeText $sXml "4" $subtitle
                Set-SlidePhoto $sXml $rXml "7" $photoId $lang
            }
            "cover_split_photo" {
                Set-ShapeText $sXml "6" $title
                Set-ShapeText $sXml "7" $subtitle
                if ($dept) { Set-ShapeText $sXml "2" $dept }
                if ($date) { Set-ShapeText $sXml "10" $date }
                if ($conf) { Set-ShapeText $sXml "11" $conf }
                Set-SlidePhoto $sXml $rXml "3" $photoId $lang
            }
            "section_emerald" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
            }
            "section_sand_gold" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
            }
            "section_photo_banner" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                Set-SlidePhoto $sXml $rXml "6" $photoId $lang
            }
            "content_split_photo" {
                Set-ShapeText $sXml "7" $title
                Set-ShapeText $sXml "9" $subtitle
                Set-ShapeText $sXml "11" $heading
                Set-ShapeText $sXml "10" $body
                Set-SlidePhoto $sXml $rXml "4" $photoId $lang
            }
            "content_two_photos" {
                Set-ShapeText $sXml "7" $title
                Set-ShapeText $sXml "9" $subtitle
                Set-ShapeText $sXml "11" $heading
                Set-ShapeText $sXml "10" $body
                Set-SlidePhoto $sXml $rXml "2" $photoId $lang
            }
            "three_pillars_icons" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                $hIds = @("63", "8", "12")
                $bIds = @("62", "7", "11")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "three_cards_with_photo" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                Set-SlidePhoto $sXml $rXml "4" $photoId $lang
                $hIds = @("58", "9", "13")
                $bIds = @("70", "7", "11")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "agenda_four_items" {
                Set-ShapeText $sXml "22" $title
                Set-ShapeText $sXml "23" $subtitle
                Set-SlidePhoto $sXml $rXml "2" $photoId $lang
                $nIds = @("90", "4", "7", "10")
                $hIds = @("87", "25", "27", "29")
                $bIds = @("88", "26", "28", "30")
                for ($i=0; $i -lt [math]::Min(4, $items.Count); $i++) {
                    if ($items[$i].number) { Set-ShapeText $sXml $nIds[$i] ([string]$items[$i].number) }
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "three_rows_icons_photo" {
                Set-ShapeText $sXml "24" $title
                Set-ShapeText $sXml "25" $subtitle
                Set-SlidePhoto $sXml $rXml "2" $photoId $lang
                $hIds = @("28", "30", "32")
                $bIds = @("27", "29", "31")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "highlight_banner_photo" {
                Set-ShapeText $sXml "28" $title
                Set-ShapeText $sXml "29" $subtitle
                Set-ShapeText $sXml "32" $heading
                Set-ShapeText $sXml "31" $body
                Set-SlidePhoto $sXml $rXml "10" $photoId $lang
            }
            "kpi_metrics_chart" {
                Set-ShapeText $sXml "7" $title
                Set-ShapeText $sXml "8" $subtitle
                $vIds = @("12", "13", "14")
                $dIds = @("9", "10", "11")
                $srcList = if ($metrics.Count -gt 0) { $metrics } else { $items }
                for ($i=0; $i -lt [math]::Min(3, $srcList.Count); $i++) {
                    $val = if ($srcList[$i].value) { $srcList[$i].value } else { $srcList[$i].heading }
                    $desc = if ($srcList[$i].description) { $srcList[$i].description } else { $srcList[$i].body }
                    Set-ShapeText $sXml $vIds[$i] ([string]$val)
                    Set-ShapeText $sXml $dIds[$i] ([string]$desc)
                }
            }
            "timeline_three_horizons" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                $hIds = @("94", "95", "96")
                $dIds = @("100", "99", "98")
                $bIds = @("103", "104", "105")
                for ($i=0; $i -lt [math]::Min(3, $items.Count); $i++) {
                    $hor = if ($items[$i].horizon) { $items[$i].horizon } else { $items[$i].heading }
                    $dur = if ($items[$i].duration) { $items[$i].duration } else { $items[$i].number }
                    if ($hor) { Set-ShapeText $sXml $hIds[$i] ([string]$hor) }
                    if ($dur) { Set-ShapeText $sXml $dIds[$i] ([string]$dur) }
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "four_grid_infographic" {
                Set-ShapeText $sXml "24" $title
                Set-ShapeText $sXml "25" $subtitle
                $nIds = @("27", "30", "33", "36")
                $hIds = @("28", "31", "34", "37")
                $bIds = @("26", "29", "32", "35")
                for ($i=0; $i -lt [math]::Min(4, $items.Count); $i++) {
                    if ($items[$i].number) { Set-ShapeText $sXml $nIds[$i] ([string]$items[$i].number) }
                    Set-ShapeText $sXml $hIds[$i] ([string]$items[$i].heading)
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "process_four_stages" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                $sIds = @("110", "111", "113", "112")
                $bIds = @("6", "7", "8", "132")
                for ($i=0; $i -lt [math]::Min(4, $items.Count); $i++) {
                    $stName = if ($items[$i].stage_name) { $items[$i].stage_name } else { $items[$i].heading }
                    if ($stName) { Set-ShapeText $sXml $sIds[$i] ([string]$stName) }
                    Set-ShapeText $sXml $bIds[$i] ([string]$items[$i].body)
                }
            }
            "data_table_slide" {
                Set-ShapeText $sXml "2" $title
                Set-ShapeText $sXml "3" $subtitle
                Set-ShapeText $sXml "11" $heading
                Set-ShapeText $sXml "9" $body
                Set-SlideTable $sXml $slideSpec.table_headers $slideSpec.table_rows
            }
            "closing_thank_you" {
                if ($title) { Set-ShapeText $sXml "2" $title }
            }
        }
    }
}

# Open the copied PPTX zip archive for update
$zip = [System.IO.Compression.ZipFile]::Open($outPptxPath, [System.IO.Compression.ZipArchiveMode]::Update)

# Read all template slides into memory first so we can clone even if same layout is used multiple times
$templateSlideXml = @{}
$templateSlideRels = @{}
foreach ($entry in @($zip.Entries | Where-Object { $_.FullName -like "ppt/slides/slide*.xml" })) {
    $sr = New-Object System.IO.StreamReader($entry.Open(), [System.Text.Encoding]::UTF8)
    $templateSlideXml[$entry.Name] = $sr.ReadToEnd()
    $sr.Close()
}
foreach ($entry in @($zip.Entries | Where-Object { $_.FullName -like "ppt/slides/_rels/slide*.xml.rels" })) {
    $sr = New-Object System.IO.StreamReader($entry.Open(), [System.Text.Encoding]::UTF8)
    $templateSlideRels[$entry.Name] = $sr.ReadToEnd()
    $sr.Close()
}

# Remove all existing slide*.xml and slide*.xml.rels and notesSlides references from slides
foreach ($entry in @($zip.Entries | Where-Object { $_.FullName -like "ppt/slides/slide*.xml" -or $_.FullName -like "ppt/slides/_rels/slide*.xml.rels" })) {
    $entry.Delete()
}

# Build new slides from specJson.slides
$slidesSpec = @($specJson.slides)
$newSlideCount = $slidesSpec.Count

for ($idx = 0; $idx -lt $newSlideCount; $idx++) {
    $sSpec = $slidesSpec[$idx]
    $newNum = $idx + 1
    $lid = $sSpec.layout_id
    if (-not $layoutMap.ContainsKey($lid)) {
        $lid = "content_split_photo"
    }
    $lInfo = $layoutMap[$lid]
    $srcSlideNum = if ($lang -eq "AR") { $lInfo.ar_slide } else { $lInfo.en_slide }
    
    $rawXml = $templateSlideXml["slide${srcSlideNum}.xml"]
    $rawRels = $templateSlideRels["slide${srcSlideNum}.xml.rels"]

    $sXml = [xml]$rawXml
    $rXml = [xml]$rawRels

    # Remove notesSlide relationship if present so multiple cloned slides don't conflict on the same notesSlide
    $notesRels = @($rXml.SelectNodes("//*[local-name()='Relationship' and contains(@Type, 'notesSlide')]"))
    foreach ($nr in $notesRels) {
        [void]$nr.ParentNode.RemoveChild($nr)
    }

    Populate-Slide $sXml $rXml $sSpec $newNum $lang

    # Write slide{newNum}.xml
    $sEntry = $zip.CreateEntry("ppt/slides/slide${newNum}.xml", [System.IO.Compression.CompressionLevel]::Optimal)
    $sw = New-Object System.IO.StreamWriter($sEntry.Open(), (New-Object System.Text.UTF8Encoding($false)))
    $sXml.Save($sw)
    $sw.Close()

    # Write _rels/slide{newNum}.xml.rels
    $rEntry = $zip.CreateEntry("ppt/slides/_rels/slide${newNum}.xml.rels", [System.IO.Compression.CompressionLevel]::Optimal)
    $rw = New-Object System.IO.StreamWriter($rEntry.Open(), (New-Object System.Text.UTF8Encoding($false)))
    $rXml.Save($rw)
    $rw.Close()
}

# Update ppt/_rels/presentation.xml.rels and ppt/presentation.xml
$presRelsEntry = $zip.GetEntry("ppt/_rels/presentation.xml.rels")
$sr = New-Object System.IO.StreamReader($presRelsEntry.Open(), [System.Text.Encoding]::UTF8)
$presRelsXml = [xml]$sr.ReadToEnd()
$sr.Close()

# Remove old slide relationships
$oldSlideRels = @($presRelsXml.SelectNodes("//*[local-name()='Relationship' and contains(@Type, '/slide') and not(contains(@Type, 'slideMaster'))]"))
foreach ($or in $oldSlideRels) {
    [void]$or.ParentNode.RemoveChild($or)
}

# Update ppt/presentation.xml
$presEntry = $zip.GetEntry("ppt/presentation.xml")
$sr = New-Object System.IO.StreamReader($presEntry.Open(), [System.Text.Encoding]::UTF8)
$presXml = [xml]$sr.ReadToEnd()
$sr.Close()

$sldIdLst = $presXml.SelectSingleNode("//*[local-name()='sldIdLst']")
$sldIdLst.RemoveAll()

$pNs = "http://schemas.openxmlformats.org/presentationml/2006/main"
$rNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
$relNs = "http://schemas.openxmlformats.org/package/2006/relationships"

for ($idx = 0; $idx -lt $newSlideCount; $idx++) {
    $newNum = $idx + 1
    $rId = "rIdSlide${newNum}"
    $sldIdVal = 256 + $newNum

    # Add to presentation.xml.rels
    $relNode = $presRelsXml.CreateElement("Relationship", $relNs)
    $relNode.SetAttribute("Id", $rId)
    $relNode.SetAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide")
    $relNode.SetAttribute("Target", "slides/slide${newNum}.xml")
    [void]$presRelsXml.DocumentElement.AppendChild($relNode)

    # Add to sldIdLst in presentation.xml
    $sldIdNode = $presXml.CreateElement("p", "sldId", $pNs)
    $sldIdNode.SetAttribute("id", "$sldIdVal")
    $attr = $presXml.CreateAttribute("r", "id", $rNs)
    $attr.Value = $rId
    [void]$sldIdNode.Attributes.Append($attr)
    [void]$sldIdLst.AppendChild($sldIdNode)
}

$presRelsEntry.Delete()
$newPresRels = $zip.CreateEntry("ppt/_rels/presentation.xml.rels", [System.IO.Compression.CompressionLevel]::Optimal)
$prw = New-Object System.IO.StreamWriter($newPresRels.Open(), (New-Object System.Text.UTF8Encoding($false)))
$presRelsXml.Save($prw)
$prw.Close()

$presEntry.Delete()
$newPres = $zip.CreateEntry("ppt/presentation.xml", [System.IO.Compression.CompressionLevel]::Optimal)
$pw = New-Object System.IO.StreamWriter($newPres.Open(), (New-Object System.Text.UTF8Encoding($false)))
$presXml.Save($pw)
$pw.Close()

# Update [Content_Types].xml
$ctEntry = $zip.GetEntry("[Content_Types].xml")
$sr = New-Object System.IO.StreamReader($ctEntry.Open(), [System.Text.Encoding]::UTF8)
$ctXml = [xml]$sr.ReadToEnd()
$sr.Close()

$oldSlideCt = @($ctXml.SelectNodes("//*[local-name()='Override' and starts-with(@PartName, '/ppt/slides/slide')]"))
foreach ($oct in $oldSlideCt) {
    [void]$oct.ParentNode.RemoveChild($oct)
}
$ctNs = "http://schemas.openxmlformats.org/package/2006/content-types"
for ($idx = 0; $idx -lt $newSlideCount; $idx++) {
    $newNum = $idx + 1
    $ov = $ctXml.CreateElement("Override", $ctNs)
    $ov.SetAttribute("PartName", "/ppt/slides/slide${newNum}.xml")
    $ov.SetAttribute("ContentType", "application/vnd.openxmlformats-officedocument.presentationml.slide+xml")
    [void]$ctXml.DocumentElement.AppendChild($ov)
}
$ctEntry.Delete()
$newCt = $zip.CreateEntry("[Content_Types].xml", [System.IO.Compression.CompressionLevel]::Optimal)
$cw = New-Object System.IO.StreamWriter($newCt.Open(), (New-Object System.Text.UTF8Encoding($false)))
$ctXml.Save($cw)
$cw.Close()

# Prune unreferenced media files so output .pptx is ultra-lightweight (1-3 MB instead of 20 MB)
$referencedMedia = @{}
foreach ($relEntry in @($zip.Entries | Where-Object { $_.FullName -like "*.rels" })) {
    $sr = New-Object System.IO.StreamReader($relEntry.Open(), [System.Text.Encoding]::UTF8)
    $rx = [xml]$sr.ReadToEnd()
    $sr.Close()
    foreach ($r in $rx.SelectNodes("//*[local-name()='Relationship']")) {
        $t = $r.Target
        if ($t -like "*media/*") {
            $mName = ($t -replace "^.*media/","").ToLower()
            $referencedMedia[$mName] = $true
        }
    }
}
foreach ($mEntry in @($zip.Entries | Where-Object { $_.FullName -like "ppt/media/*" })) {
    if (-not $referencedMedia.ContainsKey($mEntry.Name.ToLower())) {
        $mEntry.Delete()
    }
}

$zip.Dispose()
$finalMB = [math]::Round((Get-Item $outPptxPath).Length / 1MB, 2)
Write-Output "SUCCESS: Generated $outPptxPath ($newSlideCount slides, $finalMB MB)"
