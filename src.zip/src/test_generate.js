const { handleToolCall } = require('./mcp_server');

// 1. Generate an 8-slide Arabic (AR) Executive Presentation for RCMC
const arResult = handleToolCall('generate_rcmc_presentation', {
  presentation_id: 'RCMC_Makkah_Mobility_Strategy_AR',
  language: 'AR',
  title: 'استراتيجية النقل وإدارة الحشود في مدينة مكة المكرمة والمشاعر المقدسة',
  slides: [
    {
      layout_id: 'cover_split_photo',
      title: 'استراتيجية النقل المتكامل وإدارة الحشود ٢٠٢٦',
      subtitle: 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة',
      department: 'قطاع النقل والخدمات اللوجستية',
      date: 'نوفمبر ٢٠٢٦ م',
      confidentiality: 'سري وغير قابل للتداول',
      photo_id: 'photo_01'
    },
    {
      layout_id: 'agenda_four_items',
      title: 'محاور العرض الاستراتيجي',
      subtitle: 'نظرة شاملة على خطط التطوير والتشغيل',
      photo_id: 'photo_10',
      items: [
        { number: '01', heading: 'البنية التحتية وشبكة الطرق الدائرية', body: 'استكمال المحاور الرئيسية والجسور لربط المشاعر المقدسة بالمنطقة المركزية.' },
        { number: '02', heading: 'منظومة حافلات مكة والنقل الترددي', body: 'رفع كفاءة الأسطول التشغيلي وتقليص زمن التقاطر في أوقات الذروة.' },
        { number: '03', heading: 'إثراء التجربة وإحياء المواقع التاريخية', body: 'تأهيل مسار عين زبيدة والمواقع التاريخية لخدمة ضيوف الرحمن.' },
        { number: '04', heading: 'مؤشرات الأداء وخارطة الطريق التنفيذية', body: 'قياس الأثر التشغيلي ومراحل التنفيذ حتى موسم حج ١٤٤٨ هـ.' }
      ]
    },
    {
      layout_id: 'section_emerald',
      title: 'المحور الأول: تطوير منظومة النقل والحشود',
      subtitle: 'حلول ذكية ومستدامة لخدمة ضيوف الرحمن'
    },
    {
      layout_id: 'content_split_photo',
      title: 'منظومة حافلات مكة والمحطات المركزية',
      subtitle: 'كفاءة تشغيلية بمعايير عالمية',
      heading: 'تكامل مسارات النقل العام مع قطار المشاعر',
      body: 'تعمل الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة على تطوير شبكة متكاملة للنقل العام تربط كافة أحياء مكة المكرمة ومواقف السيارات بمداخل المنطقة المركزية والمشاعر المقدسة، مما يسهم في خفض الازدحام المروري وتسهيل وصول المعتمرين والحجاج بأعلى معايير الأمان والراحة.',
      photo_id: 'photo_19'
    },
    {
      layout_id: 'three_pillars_icons',
      title: 'الركائز الاستراتيجية لإدارة الحشود',
      subtitle: 'توظيف التقنيات الحديثة والذكاء الاصطناعي',
      items: [
        { heading: 'الرصد اللحظي والتحكم', body: 'منظومة غرف تحكم ذكية لمتابعة الكثافات البشرية في صحن المطاف والمنطقة المركزية على مدار الساعة.', icon_id: 'icon_03' },
        { heading: 'كفاءة البنية التحتية', body: 'تطوير جسور المشاة والأنفاق وفصل حركة المشاة عن المركبات لضمان انسيابية التفويج.', icon_id: 'icon_10' },
        { heading: 'الحوكمة والتنسيق المشترك', body: 'تكامل تام بين كافة الجهات العاملة في منظومة الحج والعمرة وفق مؤشرات أداء موحدة.', icon_id: 'icon_07' }
      ]
    },
    {
      layout_id: 'kpi_metrics_chart',
      title: 'المستهدفات ومؤشرات الأداء الرئيسية (KPIs)',
      subtitle: 'الأثر المتوقع للمبادرات الاستراتيجية ٢٠٢٦ - ٢٠٢٨',
      metrics: [
        { value: '4.5M+', description: 'طاقة استيعابية للنقل الترددي اليومي خلال أوقات الذروة في مواسم الحج ورمضان.' },
        { value: '35%', description: 'خفض في زمن التنقل بين المشاعر المقدسة والمنطقة المركزية عبر المحاور الجديدة.' },
        { value: '98%', description: 'نسبة رضا ضيوف الرحمن المستهدفة عن جودة خدمات النقل وإدارة الحشود.' }
      ]
    },
    {
      layout_id: 'timeline_three_horizons',
      title: 'الآفاق الزمنية لخطة التحول التشغيلي (٢٠٢٦ - ٢٠٣٠)',
      subtitle: 'مراحل التنفيذ المتدرج لمنظومة النقل وإدارة الحشود',
      items: [
        { horizon: 'المدى القريب (المسار السريع)', duration: '٦ أشهر', body: 'إطلاق حزمة التحسينات الفورية لإدارة الحشود وتوسعة مواقف حافلات مكة وتحديث اللوحات الإرشادية.' },
        { horizon: 'المدى المتوسط (تكامل البنية)', duration: '١٨ شهرًا', body: 'اكتمال التقاطعات الرئيسية على الطرق الدائرية وتدشين مسار عين زبيدة وممرات المشاة المظللة.' },
        { horizon: 'المدى الاستراتيجي (التحول الشامل)', duration: '٣٦ شهرًا', body: 'التشغيل الكامل لمنظومة النقل الذكي بالحافلات الكهربائية والربط الرقمي الشامل مع قطار الحرمين والمشاعر.' }
      ]
    },
    {
      layout_id: 'process_four_stages',
      title: 'خارطة طريق تنفيذ مشاريع المشاعر المقدسة',
      subtitle: 'حوكمة مراحل الإنجاز التشغيلي حتى موسم حج ١٤٤٨ هـ',
      items: [
        { stage_name: 'المرحلة الأولى: التخطيط والتصميم', number: 'الربع الأول ٢٠٢٦', body: 'إتمام المخططات الهندسية ونماذج محاكاة حركة الحشود واعتماد المعايير التصميمية للهيئة.' },
        { stage_name: 'المرحلة الثانية: الترسية والتجهيز', number: 'الربع الثاني ٢٠٢٦', body: 'ترسية عقود البنية التحتية وتأهيل المقاولين وتجهيز مناطق العمل خارج أوقات الذروة.' },
        { stage_name: 'المرحلة الثالثة: التنفيذ الميداني', number: '٢٠٢٦ - ٢٠٢٧', body: 'تنفيذ الأعمال المدنية والأنفاق والجسور وتثبيت أنظمة الرصد والمراقبة الذكية.' },
        { stage_name: 'المرحلة الرابعة: الاختبار والتشغيل', number: 'موسم حج ١٤٤٨ هـ', body: 'إجراء التجارب الفرضية ومحاكاة المواسم والتشغيل الفعلي الكامل للمنظومة.' }
      ]
    },
    {
      layout_id: 'data_table_slide',
      title: 'ملخص المشاريع الرأسمالية ذات الأولوية',
      subtitle: 'البرنامج التنفيذي لقطاع النقل والمشاعر',
      heading: 'متابعة الإنجاز الفعلي',
      body: 'تخضع كافة المشاريع لحوكمة دقيقة ومراجعة دورية لضمان جاهزيتها قبل حلول المواسم التشغيلية.',
      table_headers: ['اسم المشروع', 'النطاق الجغرافي', 'نسبة الإنجاز', 'الحالة', 'موعد الإطلاق'],
      table_rows: [
        ['توسعة محطات حافلات مكة', 'المنطقة المركزية', '92%', 'في المسار', 'الربع الأول ٢٠٢٧'],
        ['تأهيل مسار عين زبيدة التاريخي', 'المشاعر المقدسة', '85%', 'في المسار', 'الربع الثاني ٢٠٢٧'],
        ['تطوير تقاطعات الطريق الدائري الثالث', 'مدينة مكة المكرمة', '78%', 'قيد التنفيذ', 'الربع الثالث ٢٠٢٧'],
        ['منصة التوأم الرقمي لإدارة الحشود', 'المسجد الحرام والمشاعر', '95%', 'مكتمل جزئياً', 'الربع الرابع ٢٠٢٦']
      ]
    },
    {
      layout_id: 'closing_thank_you',
      title: 'شكرًا لكم'
    }
  ]
});

console.log('AR Result:', JSON.parse(arResult.content[0].text));

// 2. Generate a 6-slide English (EN) Executive Presentation for RCMC
const enResult = handleToolCall('generate_rcmc_presentation', {
  presentation_id: 'RCMC_Urban_Heritage_Strategy_EN',
  language: 'EN',
  title: 'Makkah Urban Development & Historic Sites Revitalization',
  slides: [
    {
      layout_id: 'cover_split_photo',
      title: 'Makkah Urban Development & Heritage Strategy',
      subtitle: 'Royal Commission for Makkah City and Holy Sites',
      department: 'Urban Planning & Heritage Sector',
      date: 'November 2026',
      confidentiality: 'Confidential and non-negotiable',
      photo_id: 'photo_07'
    },
    {
      layout_id: 'three_cards_with_photo',
      title: 'Strategic Vision for Makkah & Holy Sites',
      subtitle: 'Balancing Modern Infrastructure with Authentic Islamic Identity',
      photo_id: 'photo_22',
      items: [
        { heading: 'Central Area Excellence', body: 'Enhancing pedestrian connectivity and architectural harmony around the Grand Mosque.' },
        { heading: 'Ain Zubaydah Revitalization', body: 'Preserving and activating historic water aqueducts and stone arches as cultural landmarks.' },
        { heading: 'Green Makkah Corridors', body: 'Expanding palm-lined boulevards, shaded pedestrian walkways, and sustainable mobility.' }
      ]
    },
    {
      layout_id: 'timeline_three_horizons',
      title: 'Implementation Horizons (2026 - 2030)',
      subtitle: 'Phased Execution Across Makkah and the Holy Sites',
      items: [
        { horizon: 'Short Term Horizon', duration: '6 Months', body: 'Immediate crowd flow optimizations, signage unification, and rapid bus depot expansion.' },
        { horizon: 'Medium Term Horizon', duration: '18 Months', body: 'Completion of ring road interchanges, pedestrian bridges, and Ain Zubaydah visitor trails.' },
        { horizon: 'Long Term Horizon', duration: '36 Months', body: 'Full smart-city integration, autonomous shuttle corridors, and Vision 2030 capacity targets.' }
      ]
    },
    {
      layout_id: 'four_grid_infographic',
      title: 'Key Governance & Operational Quadrants',
      subtitle: 'Integrated RCMC Delivery Framework',
      items: [
        { number: '01', heading: 'Master Planning', body: 'Comprehensive spatial planning across Makkah and Mashair.' },
        { number: '02', heading: 'Smart Mobility', body: 'Multi-modal transit uniting Haramain Rail, Metro, and Makkah Buses.' },
        { number: '03', heading: 'Cultural Enrichment', body: 'Restoring historic Islamic monuments and enriching pilgrim journeys.' },
        { number: '04', heading: 'Sustainability', body: 'Green landscaping, shading, and resource efficiency across all sites.' }
      ]
    },
    {
      layout_id: 'process_four_stages',
      title: 'Project Delivery Lifecycle',
      subtitle: 'RCMC Stage-Gate Governance',
      items: [
        { stage_name: 'Stage 1: Design', body: 'Architectural alignment with RCMC charter and Islamic heritage standards.' },
        { stage_name: 'Stage 2: Engineering', body: 'Detailed civil engineering, crowd simulation, and infrastructure modeling.' },
        { stage_name: 'Stage 3: Execution', body: 'Accelerated off-season construction with zero disruption to pilgrims.' },
        { stage_name: 'Stage 4: Operations', body: '24/7 seasonal readiness, live KPI monitoring, and continuous optimization.' }
      ]
    },
    {
      layout_id: 'closing_thank_you',
      title: 'Thank You'
    }
  ]
});

console.log('EN Result:', JSON.parse(enResult.content[0].text));
