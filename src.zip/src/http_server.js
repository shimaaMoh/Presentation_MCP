#!/usr/bin/env node
/**
 * RCMC Presentation MCP Server - HTTP / Cloud Run Adapter
 * Provides:
 *  - GET /openapi.json (OpenAPI 3.0 spec for Gemini Enterprise & Vertex AI Agent Builder)
 *  - POST /mcp (JSON-RPC 2.0 endpoint for MCP Clients)
 *  - GET /sse + POST /message (Standard MCP SSE Transport)
 *  - POST /api/:toolName (Direct REST endpoints for Gemini Enterprise / Vertex AI)
 *  - GET /canvas/:id (Live interactive HTML5 Canvas presentation)
 *  - GET /download/:filename (Direct download of generated native .pptx)
 *  - GET /health (Healthcheck for Cloud Run)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { handleToolCall, TOOLS } = require('./mcp_server');
const { uploadToGcs, GCS_BUCKET } = require('./gcs_uploader');

const PORT = parseInt(process.env.PORT || '8080', 10);
const OUTPUT_DIR = path.resolve(__dirname, '..', 'output');

if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// Active SSE client connections
const sseClients = new Map();

/**
 * Uploads generated artifacts to GCS and enriches the tool response with direct GCS URLs
 */
function sanitizeUserFolder(email) {
  if (!email || typeof email !== 'string') return 'general';
  const cleaned = email.trim().toLowerCase().replace(/[^a-z0-9@._-]/g, '_');
  return cleaned || 'general';
}

/**
 * Uploads generated artifacts to GCS and enriches the tool response with V4 Signed URLs
 */
async function enrichToolResultWithUrls(rawRes, hostUrl, reqHeaders = {}, toolArgs = {}) {
  try {
    if (!rawRes || !rawRes.content || !rawRes.content[0] || !rawRes.content[0].text) return rawRes;
    const parsed = JSON.parse(rawRes.content[0].text);
    if (parsed.presentation_id) {
      const presId = parsed.presentation_id;
      const pptxPath = path.join(OUTPUT_DIR, `${presId}.pptx`);
      const htmlPath = path.join(OUTPUT_DIR, `${presId}_canvas.html`);

      // Extract user email if passed by LLM or forwarded in HTTP headers
      let userEmail = (toolArgs && toolArgs.user_email) || '';
      if (!userEmail && reqHeaders) {
        const hEmail = reqHeaders['x-goog-authenticated-user-email'] || reqHeaders['x-forwarded-user'] || '';
        if (hEmail) {
          userEmail = hEmail.replace(/^accounts\.google\.com:/, '').trim();
        }
      }
      const userFolder = sanitizeUserFolder(userEmail);

      // Fallback URLs (Cloud Run direct routes)
      let pptxUrl = `${hostUrl}/download/${presId}.pptx`;
      let canvasUrl = `${hostUrl}/canvas/${presId}`;

      // 1. Upload genuine .pptx to GCS inside the user's dedicated folder
      const pptxUpload = await uploadToGcs(
        pptxPath,
        `presentations/${userFolder}/${presId}.pptx`,
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        `${presId}.pptx`,
        GCS_BUCKET,
        'attachment'
      );

      if (pptxUpload && pptxUpload.success) {
        pptxUrl = pptxUpload.gcs_url;
        parsed.gcs_pptx_uri = pptxUpload.gs_uri;
        console.log(`[GCS Upload Success] PPTX (${userFolder}): ${pptxUpload.gcs_url}`);
      }

      // 2. Update download link inside Canvas HTML to point directly to GCS .pptx
      if (fs.existsSync(htmlPath)) {
        let hHtml = fs.readFileSync(htmlPath, 'utf8');
        hHtml = hHtml.replace(/href="file:\/\/\/[^"]+"/g, `href="${pptxUrl}"`);
        fs.writeFileSync(htmlPath, hHtml, 'utf8');
      }

      // 3. Upload pixel-perfect HTML5 Canvas to GCS with inline disposition for instant browser viewing
      const htmlUpload = await uploadToGcs(
        htmlPath,
        `presentations/${userFolder}/${presId}_canvas.html`,
        'text/html; charset=utf-8',
        `${presId}_canvas.html`,
        GCS_BUCKET,
        'inline'
      );

      if (htmlUpload && htmlUpload.success) {
        canvasUrl = htmlUpload.gcs_url;
        parsed.gcs_canvas_uri = htmlUpload.gs_uri;
        console.log(`[GCS Upload Success] Canvas HTML (${userFolder}): ${htmlUpload.gcs_url}`);
      }

      const isAr = !parsed.language || parsed.language.toUpperCase() === 'AR';
      parsed.pptx_download_url = pptxUrl;
      parsed.canvas_url = canvasUrl;
      parsed.canvas_label = isAr
        ? 'استعراض العرض التفاعلي (يتضمن زر التحميل المباشر)'
        : 'Interactive Presentation View (Includes direct download)';
      parsed.pptx_label = isAr
        ? 'تحميل العرض بقالب الهيئة الملكية الرسمي (.pptx)'
        : "Download the presentation in RCMC's official template (.pptx)";
      parsed.user_email = userEmail || 'general';
      parsed.user_folder = userFolder;
      parsed.storage_bucket = GCS_BUCKET;
      parsed.expires_in = '30 minutes';
      rawRes.content[0].text = JSON.stringify(parsed, null, 2);
    }
  } catch (e) {
    console.error(`[enrichToolResultWithUrls Error]: ${e.message}`);
  }
  return rawRes;
}

function sendJson(res, statusCode, data, extraHeaders = {}) {
  const body = Buffer.from(JSON.stringify(data), 'utf8');
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Content-Length': String(body.length),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Mcp-Session-Id, MCP-Protocol-Version, Accept',
    'Access-Control-Expose-Headers': 'Mcp-Session-Id, MCP-Protocol-Version',
    ...extraHeaders
  });
  res.end(body);
}

function getOpenApiSpec(hostUrl) {
  return {
    openapi: '3.0.3',
    info: {
      title: 'RCMC Presentation & Canvas API for Gemini Enterprise',
      description: 'Official API for Royal Commission for Makkah City and Holy Sites (RCMC) to generate on-brand Arabic and English presentations with live Canvas preview and native PPTX downloads.',
      version: '1.0.0'
    },
    servers: [{ url: hostUrl }],
    paths: {
      '/api/list_rcmc_layouts': {
        post: {
          operationId: 'list_rcmc_layouts',
          summary: 'List official RCMC slide layouts, color palette, and Suisse Intl typography',
          requestBody: {
            required: false,
            content: {
              'application/json': {
                schema: TOOLS.find(t => t.name === 'list_rcmc_layouts').inputSchema
              }
            }
          },
          responses: {
            '200': { description: 'RCMC slide layout specifications and brand guidelines' }
          }
        }
      },
      '/api/search_rcmc_media_library': {
        post: {
          operationId: 'search_rcmc_media_library',
          summary: 'Search internal RCMC photography and icon bank (Makkah, Haram, Holy Sites, Transport, Heritage)',
          requestBody: {
            required: false,
            content: {
              'application/json': {
                schema: TOOLS.find(t => t.name === 'search_rcmc_media_library').inputSchema
              }
            }
          },
          responses: {
            '200': { description: 'Matching photos and icons with tags and descriptions' }
          }
        }
      },
      '/api/generate_rcmc_presentation': {
        post: {
          operationId: 'generate_rcmc_presentation',
          summary: 'Generate an official RCMC presentation in Arabic or English with Canvas link and PPTX download',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: TOOLS.find(t => t.name === 'generate_rcmc_presentation').inputSchema
              }
            }
          },
          responses: {
            '200': { description: 'Presentation generated successfully with canvas_url and pptx_url' }
          }
        }
      },
      '/api/update_rcmc_slide': {
        post: {
          operationId: 'update_rcmc_slide',
          summary: 'Update, insert, or replace a slide in an existing RCMC presentation',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: TOOLS.find(t => t.name === 'update_rcmc_slide').inputSchema
              }
            }
          },
          responses: {
            '200': { description: 'Updated presentation with refreshed canvas and pptx links' }
          }
        }
      }
    }
  };
}

const server = http.createServer((req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, Mcp-Session-Id, Accept',
      'Access-Control-Expose-Headers': 'Mcp-Session-Id'
    });
    return res.end();
  }

  const proto = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers.host || `localhost:${PORT}`;
  const hostUrl = `${proto}://${host}`;
  const urlObj = new URL(req.url, hostUrl);
  const pathname = urlObj.pathname;

  // 1. Healthcheck (GET /health or GET / when not requesting SSE)
  if (pathname === '/health' || (pathname === '/' && req.method === 'GET' && !(req.headers.accept || '').includes('text/event-stream'))) {
    return sendJson(res, 200, {
      status: 'ok',
      service: 'rcmc-presentation-mcp',
      version: '1.0.0',
      cloud_run: true,
      gemini_enterprise_openapi: `${hostUrl}/openapi.json`,
      mcp_endpoint: `${hostUrl}/mcp`,
      sse_endpoint: `${hostUrl}/sse`
    });
  }

  // 2. OpenAPI Spec for Gemini Enterprise & Vertex AI Agent Builder
  if (pathname === '/openapi.json' && req.method === 'GET') {
    return sendJson(res, 200, getOpenApiSpec(hostUrl));
  }

  // 3. Tools list endpoint
  if (pathname === '/tools' && req.method === 'GET') {
    return sendJson(res, 200, { tools: TOOLS });
  }

  // 4. REST API Endpoints for Gemini Enterprise / Vertex AI
  if (pathname.startsWith('/api/') && req.method === 'POST') {
    const toolName = pathname.replace('/api/', '');
    let bodyStr = '';
    req.on('data', chunk => { bodyStr += chunk; });
    req.on('end', async () => {
      try {
        const args = JSON.parse(bodyStr || '{}');
        const rawRes = handleToolCall(toolName, args);
        await enrichToolResultWithUrls(rawRes, hostUrl, req.headers, args);
        const parsed = JSON.parse(rawRes.content[0].text);
        return sendJson(res, 200, parsed);
      } catch (err) {
        return sendJson(res, 500, { error: err.message });
      }
    });
    return;
  }

  // 5. MCP Streamable HTTP Endpoint (stateless JSON response mode with explicit Content-Length)
  if (pathname === '/mcp' || pathname === '/') {
    if (req.method === 'DELETE') {
      console.log(`[MCP DELETE] ${pathname}`);
      res.writeHead(200, {
        'Content-Length': '0',
        'Access-Control-Allow-Origin': '*'
      });
      return res.end();
    }

    if (req.method === 'GET') {
      const accept = (req.headers.accept || '').toLowerCase();
      console.log(`[MCP GET] ${pathname} | Accept: ${req.headers.accept}`);
      if (accept.includes('text/event-stream')) {
        // Stateless Streamable HTTP: return 405 so MCP clients use POST-only JSON mode without hanging SSE streams
        res.writeHead(405, {
          'Allow': 'POST',
          'Content-Length': '0',
          'Access-Control-Allow-Origin': '*'
        });
        return res.end();
      }
      return sendJson(res, 200, {
        status: 'ok',
        mcp_endpoint: `${hostUrl}/mcp`,
        tools_count: TOOLS.length
      });
    }

    if (req.method === 'POST') {
      const chunks = [];
      req.on('data', chunk => { chunks.push(Buffer.from(chunk)); });
      req.on('end', async () => {
        try {
          const bodyStr = Buffer.concat(chunks).toString('utf8');
          console.log(`[MCP POST] ${pathname} | Accept: ${req.headers.accept} | Session: ${req.headers['mcp-session-id'] || 'none'} | Body: ${bodyStr.slice(0, 300)}`);
          const parsedBody = JSON.parse(bodyStr || '{}');
          const extraHeaders = {};
          if (req.headers['mcp-session-id']) {
            extraHeaders['Mcp-Session-Id'] = req.headers['mcp-session-id'];
          }

          const processSingleRpc = async (rpc) => {
            const id = rpc.id !== undefined ? rpc.id : null;

            // Handle JSON-RPC notifications (e.g. notifications/initialized, notifications/cancelled)
            if (rpc.id === undefined || (typeof rpc.method === 'string' && rpc.method.startsWith('notifications/'))) {
              return null;
            }

            if (rpc.method === 'initialize') {
              const clientProto = (rpc.params && rpc.params.protocolVersion) ? rpc.params.protocolVersion : '2025-11-25';
              extraHeaders['MCP-Protocol-Version'] = clientProto;
              return {
                jsonrpc: '2.0',
                id,
                result: {
                  protocolVersion: clientProto,
                  capabilities: { tools: { listChanged: false } },
                  serverInfo: { name: 'rcmc-presentation-mcp', version: '1.0.0' }
                }
              };
            }

            if (rpc.method === 'ping') {
              return { jsonrpc: '2.0', id, result: {} };
            }

            if (rpc.method === 'tools/list') {
              return { jsonrpc: '2.0', id, result: { tools: TOOLS } };
            }

            if (rpc.method === 'resources/list') {
              return { jsonrpc: '2.0', id, result: { resources: [] } };
            }

            if (rpc.method === 'prompts/list') {
              return { jsonrpc: '2.0', id, result: { prompts: [] } };
            }

            if (rpc.method === 'tools/call') {
              try {
                const rawRes = handleToolCall(rpc.params.name, rpc.params.arguments || {});
                await enrichToolResultWithUrls(rawRes, hostUrl, req.headers, rpc.params.arguments || {});
                return { jsonrpc: '2.0', id, result: rawRes };
              } catch (toolErr) {
                console.error(`[Tool Execution Error] ${rpc.params.name}:`, toolErr);
                return {
                  jsonrpc: '2.0',
                  id,
                  result: {
                    content: [{ type: 'text', text: `Tool error: ${toolErr.message}` }],
                    isError: true
                  }
                };
              }
            }

            return {
              jsonrpc: '2.0',
              id,
              error: { code: -32601, message: `Method '${rpc.method}' not supported` }
            };
          };

          if (Array.isArray(parsedBody)) {
            const responses = (await Promise.all(parsedBody.map(processSingleRpc))).filter(Boolean);
            if (responses.length === 0) {
              res.writeHead(202, { 'Access-Control-Allow-Origin': '*', 'Content-Length': '0', ...extraHeaders });
              return res.end();
            }
            return sendJson(res, 200, responses, extraHeaders);
          } else {
            const responseObj = await processSingleRpc(parsedBody);
            if (responseObj === null) {
              res.writeHead(202, { 'Access-Control-Allow-Origin': '*', 'Content-Length': '0', ...extraHeaders });
              return res.end();
            }
            return sendJson(res, 200, responseObj, extraHeaders);
          }
        } catch (err) {
          return sendJson(res, 200, {
            jsonrpc: '2.0',
            id: null,
            error: { code: -32000, message: err.message }
          });
        }
      });
      return;
    }
  }

  // 6. SSE Endpoint for Streamable MCP
  if (pathname === '/sse' && req.method === 'GET') {
    const clientId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write(`event: endpoint\ndata: /message?sessionId=${clientId}\n\n`);
    sseClients.set(clientId, res);
    req.on('close', () => { sseClients.delete(clientId); });
    return;
  }

  // 7. SSE POST Message Endpoint
  if (pathname === '/message' && req.method === 'POST') {
    const sessionId = urlObj.searchParams.get('sessionId');
    const sseRes = sseClients.get(sessionId);
    let bodyStr = '';
    req.on('data', chunk => { bodyStr += chunk; });
    req.on('end', async () => {
      try {
        const rpc = JSON.parse(bodyStr || '{}');
        let rpcRes = null;
        if (rpc.method === 'initialize') {
          rpcRes = {
            jsonrpc: '2.0',
            id: rpc.id,
            result: {
              protocolVersion: '2024-11-05',
              capabilities: { tools: {}, resources: {} },
              serverInfo: { name: 'rcmc-presentation-mcp', version: '1.0.0' }
            }
          };
        } else if (rpc.method === 'tools/list') {
          rpcRes = { jsonrpc: '2.0', id: rpc.id, result: { tools: TOOLS } };
        } else if (rpc.method === 'tools/call') {
          try {
            const rawRes = handleToolCall(rpc.params.name, rpc.params.arguments || {});
            await enrichToolResultWithUrls(rawRes, hostUrl, req.headers, rpc.params.arguments || {});
            rpcRes = { jsonrpc: '2.0', id: rpc.id, result: rawRes };
          } catch (toolErr) {
            rpcRes = {
              jsonrpc: '2.0',
              id: rpc.id,
              result: {
                content: [{ type: 'text', text: `Tool error: ${toolErr.message}` }],
                isError: true
              }
            };
          }
        }
        if (sseRes && rpcRes) {
          sseRes.write(`event: message\ndata: ${JSON.stringify(rpcRes)}\n\n`);
        }
        return sendJson(res, 202, { status: 'accepted' });
      } catch (e) {
        return sendJson(res, 500, { error: e.message });
      }
    });
    return;
  }

  // 8. Live Interactive HTML5 Canvas Route
  if (pathname.startsWith('/canvas/')) {
    const id = pathname.replace('/canvas/', '').replace(/[^a-zA-Z0-9_-]/g, '');
    const htmlFile = path.join(OUTPUT_DIR, `${id}_canvas.html`);
    if (fs.existsSync(htmlFile)) {
      let content = fs.readFileSync(htmlFile, 'utf8');
      // Update download link inside the Canvas HTML so clicking it downloads via HTTPS
      content = content.replace(
        /href="file:\/\/\/[^"]+"/g,
        `href="${hostUrl}/download/${id}.pptx"`
      );
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Access-Control-Allow-Origin': '*'
      });
      return res.end(content);
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end(`Presentation '${id}' not found. Generate it first via the MCP tool.`);
  }

  // 9. Direct PPTX Download Route
  if (pathname.startsWith('/download/')) {
    const filename = path.basename(pathname);
    const pptxFile = path.join(OUTPUT_DIR, filename);
    if (fs.existsSync(pptxFile)) {
      res.writeHead(200, {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Access-Control-Allow-Origin': '*'
      });
      return fs.createReadStream(pptxFile).pipe(res);
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end(`File '${filename}' not found.`);
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`ðŸ›ï¸ RCMC Presentation MCP Cloud Run Server listening on port ${PORT}`);
});
