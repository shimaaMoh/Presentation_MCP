#!/usr/bin/env node
/**
 * RCMC Presentation & Canvas MCP Server
 * Zero-dependency Model Context Protocol (MCP) server over stdio + optional local HTTP preview server.
 * Supports:
 *  - list_rcmc_layouts
 *  - search_rcmc_media_library
 *  - generate_rcmc_presentation
 *  - update_rcmc_slide
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { renderCanvasHtml } = require('./canvas_renderer');

const ROOT_DIR = path.resolve(__dirname, '..');
const CATALOG_PATH = path.join(__dirname, 'catalog.json');
const BUILD_SCRIPT = path.join(__dirname, 'build_pptx.ps1');
const OUTPUT_DIR = path.join(ROOT_DIR, 'output');

if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

const catalog = JSON.parse(fs.readFileSync(CATALOG_PATH, 'utf8'));

// Store active presentation specs in memory & disk so update_rcmc_slide works seamlessly
const activePresentations = new Map();

const TOOLS = [
  {
    name: 'list_rcmc_layouts',
    description:
      'Returns the official Royal Commission for Makkah City and Holy Sites (RCMC) presentation slide layouts for Arabic (AR) and English (EN), including required fields, brand guidelines, colors, and typography.',
    inputSchema: {
      type: 'object',
      properties: {}
    }
  },
  {
    name: 'search_rcmc_media_library',
    description:
      'Searches the curated RCMC internal photography and icon bank (25 high-res Makkah/Haram/Holy Sites/Infrastructure/Ain Zubaydah photos and 18 official SVG icons). Always call this or pick valid photo_id / icon_id values when generating slides.',
    inputSchema: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'Keyword to search (e.g., kaaba, haram, arafat, transport, bus, roads, heritage, ain zubaydah, night, prayer, kpi, charter)'
        }
      }
    }
  },
  {
    name: 'generate_rcmc_presentation',
    description:
      'Generates a 100% brand-compliant RCMC presentation in Arabic (AR - RTL) or English (EN - LTR) using official RCMC PowerPoint Master Templates, Suisse Intl fonts, and internal Makkah photography. Produces a genuine .pptx file uploaded directly to Google Cloud Storage for instant download.',
    inputSchema: {
      type: 'object',
      required: ['title', 'language', 'slides'],
      properties: {
        title: {
          type: 'string',
          description: 'عنوان العرض التقديمي / Presentation Title'
        },
        language: {
          type: 'string',
          enum: [
            'العربية (Arabic - RTL)',
            'English (الإنجليزية - LTR)'
          ],
          description: 'لغة العرض التقديمي / Presentation Language'
        },
        slide_count: {
          type: 'string',
          enum: [
            '4 شرائح - ملخص تنفيذي موجز (4 Slides)',
            '5 شرائح - عرض قياسي للمشاريع (5 Slides)',
            '6 شرائح - خطة استراتيجية تفصيلية (6 Slides)',
            '8 شرائح - عرض تقديمي متكامل (8 Slides)',
            '10 شرائح - ملف شامل ومفصل (10 Slides)',
            '12 شريحة - ملف استراتيجي موسع (12 Slides)'
          ],
          description: 'نطاق وحجم العرض / Presentation Scope'
        },
        slides: {
          type: 'array',
          description: 'مصفوفة الشرائح المولدة تلقائياً بواسطة المساعد الذكي / Structured slides generated automatically by the assistant',
          items: {
            type: 'object',
            required: ['layout_id', 'title'],
            properties: {
              layout_id: {
                type: 'string',
                enum: catalog.layouts.map(l => l.id),
                description: 'Official RCMC slide layout ID'
              },
              title: { type: 'string', description: 'Main slide title' },
              subtitle: { type: 'string', description: 'Supporting subtitle / eyebrow text' },
              heading: { type: 'string', description: 'Paragraph heading (for content_split_photo, highlight_banner_photo, data_table_slide)' },
              body: { type: 'string', description: 'Main narrative paragraph text' },
              department: { type: 'string', description: 'Department name (for cover slides)' },
              date: { type: 'string', description: 'Date string (for cover slides)' },
              confidentiality: { type: 'string', description: 'Confidentiality notice (for cover slides)' },
              photo_id: {
                type: 'string',
                description: 'Photo ID from RCMC catalog (photo_01 through photo_25)'
              },
              items: {
                type: 'array',
                description: 'Structured cards/pillars/agenda/timeline/stage items (3 or 4 items depending on layout)',
                items: {
                  type: 'object',
                  properties: {
                    number: { type: 'string', description: 'Item number e.g. "01", "02" or duration badge' },
                    heading: { type: 'string', description: 'Card/item heading' },
                    stage_name: { type: 'string', description: 'Stage name (for process_four_stages)' },
                    horizon: { type: 'string', description: 'Horizon label (for timeline_three_horizons)' },
                    duration: { type: 'string', description: 'Duration label (for timeline_three_horizons)' },
                    body: { type: 'string', description: 'Card/item description' },
                    icon_id: { type: 'string', description: 'Icon ID (icon_01 through icon_18)' }
                  }
                }
              },
              metrics: {
                type: 'array',
                description: 'KPI metrics (for kpi_metrics_chart, up to 3 metrics)',
                items: {
                  type: 'object',
                  properties: {
                    value: { type: 'string', description: 'Big KPI value e.g. "98%", "1.8M", "60+"' },
                    description: { type: 'string', description: 'Explanation of the KPI metric' }
                  }
                }
              },
              table_headers: {
                type: 'array',
                items: { type: 'string' },
                description: 'Column headers for data_table_slide (up to 5 columns)'
              },
              table_rows: {
                type: 'array',
                items: { type: 'array', items: { type: 'string' } },
                description: '2D array of table rows for data_table_slide (up to 7 data rows)'
              }
            }
          }
        }
      }
    }
  },
  {
    name: 'update_rcmc_slide',
    description:
      'Updates a specific slide (or inserts/deletes a slide) in an existing generated RCMC presentation and rebuilds both the native .pptx and interactive Canvas HTML.',
    inputSchema: {
      type: 'object',
      required: ['slide_index'],
      properties: {
        slide_index: {
          type: 'integer',
          description: 'رقم الشريحة المراد تعديلها (مثال: 1 للشريحة الأولى) / Slide Number to Update (e.g. 1 for first slide)'
        },
        action: {
          type: 'string',
          enum: [
            'تحديث واستبدال الشريحة الحالية (Replace Slide)',
            'إدراج شريحة جديدة بعدها (Insert New Slide After)',
            'حذف الشريحة (Delete Slide)'
          ],
          description: 'نوع الإجراء المطلوب / Action'
        },
        presentation_id: {
          type: 'string',
          description: 'معرف العرض التقديمي (يتم استنتاجه تلقائياً) / Presentation ID (auto-detected)'
        },
        slide_data: {
          type: 'object',
          description: 'محتوى الشريحة الجديدة / New slide specification object'
        }
      }
    }
  }
];

function buildPresentationFiles(spec) {
  // Normalize language to strictly 'AR' or 'EN' regardless of UI dropdown or prompt input
  const rawLang = String(spec.language || '').toUpperCase();
  const normalizedLang = (rawLang.includes('EN') || rawLang.includes('ENGLISH')) ? 'EN' : 'AR';
  spec.language = normalizedLang;

  const presId = (spec.presentation_id || `rcmc_${spec.language}_${Date.now()}`)
    .replace(/[^a-zA-Z0-9_-]/g, '_');
  spec.presentation_id = presId;

  const outPptx = path.join(OUTPUT_DIR, `${presId}.pptx`);
  const outHtml = path.join(OUTPUT_DIR, `${presId}_canvas.html`);
  const outSpec = path.join(OUTPUT_DIR, `${presId}_spec.json`);

  spec.output_pptx = outPptx;
  spec.output_html = outHtml;

  fs.writeFileSync(outSpec, JSON.stringify(spec, null, 2), 'utf8');

  // 1. Run PowerShell OpenXML builder to create the genuine .pptx from the RCMC Master Template
  const psCmd = process.platform === 'win32' ? 'powershell.exe' : 'pwsh';
  const psOutput = execFileSync(
    psCmd,
    ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', BUILD_SCRIPT, '-SpecFile', outSpec],
    { encoding: 'utf8', maxBuffer: 50 * 1024 * 1024 }
  );

  // 2. Render self-contained pixel-perfect interactive HTML5 Canvas with Suisse fonts & RCMC assets
  const htmlContent = renderCanvasHtml(spec, ROOT_DIR);
  fs.writeFileSync(outHtml, htmlContent, 'utf8');

  activePresentations.set(presId, spec);

  const pptxStat = fs.statSync(outPptx);
  return {
    presentation_id: presId,
    language: spec.language,
    title: spec.title,
    slide_count: (spec.slides || []).length,
    pptx_path: outPptx,
    pptx_size_mb: +(pptxStat.size / (1024 * 1024)).toFixed(2),
    canvas_html_path: outHtml,
    builder_log: psOutput.trim(),
    html_content: htmlContent
  };
}

function handleToolCall(name, args = {}) {
  if (name === 'list_rcmc_layouts') {
    let layouts = catalog.layouts;
    if (args.category) {
      layouts = layouts.filter(l => l.category === args.category.toLowerCase());
    }
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ brand: catalog.brand, layouts }, null, 2)
        }
      ]
    };
  }

  if (name === 'search_rcmc_media_library') {
    const q = (args.query || '').toLowerCase().trim();
    const type = args.asset_type || 'all';
    let photos = catalog.photos;
    let icons = catalog.icons;

    if (q) {
      photos = photos.filter(
        p =>
          p.title_en.toLowerCase().includes(q) ||
          p.title_ar.includes(q) ||
          p.tags.some(t => t.toLowerCase().includes(q))
      );
      icons = icons.filter(
        ic =>
          ic.name.toLowerCase().includes(q) ||
          ic.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    const result = {};
    if (type === 'all' || type === 'photos') result.photos = photos;
    if (type === 'all' || type === 'icons') result.icons = icons;

    return {
      content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
    };
  }

  if (name === 'generate_rcmc_presentation') {
    const res = buildPresentationFiles(args);
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(
            {
              status: 'success',
              message: `Generated RCMC (${res.language}) presentation with ${res.slide_count} slides.`,
              presentation_id: res.presentation_id,
              language: res.language,
              title: res.title,
              slide_count: res.slide_count,
              native_pptx_file: res.pptx_path,
              pptx_size_mb: res.pptx_size_mb
            },
            null,
            2
          )
        }
      ]
    };
  }

  if (name === 'update_rcmc_slide') {
    let presId = args.presentation_id;
    if (!presId) {
      if (activePresentations.size > 0) {
        presId = Array.from(activePresentations.keys()).pop();
      } else if (fs.existsSync(OUTPUT_DIR)) {
        const specFiles = fs.readdirSync(OUTPUT_DIR)
          .filter(f => f.endsWith('_spec.json'))
          .map(f => ({ name: f.replace('_spec.json', ''), time: fs.statSync(path.join(OUTPUT_DIR, f)).mtimeMs }))
          .sort((a, b) => b.time - a.time);
        if (specFiles.length > 0) {
          presId = specFiles[0].name;
        }
      }
    }
    if (!presId) {
      throw new Error('No active presentation found to update. Please generate a presentation first.');
    }

    let spec = activePresentations.get(presId);
    if (!spec) {
      const specPath = path.join(OUTPUT_DIR, `${presId}_spec.json`);
      if (fs.existsSync(specPath)) {
        spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));
      } else {
        throw new Error(`Presentation '${presId}' not found.`);
      }
    }
    const idx = Math.max(0, (args.slide_index || 1) - 1);
    const rawAction = String(args.action || 'replace').toLowerCase();
    let action = 'replace';
    if (rawAction.includes('delete') || rawAction.includes('حذف')) {
      action = 'delete';
    } else if (rawAction.includes('insert') || rawAction.includes('إدراج') || rawAction.includes('إضافة')) {
      action = 'insert_after';
    } else {
      action = 'replace';
    }

    if (action === 'delete') {
      spec.slides.splice(idx, 1);
    } else if (action === 'insert_after') {
      spec.slides.splice(idx + 1, 0, args.slide_data);
    } else {
      spec.slides[idx] = Object.assign({}, spec.slides[idx] || {}, args.slide_data);
    }

    const res = buildPresentationFiles(spec);
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(
            {
              status: 'updated',
              presentation_id: res.presentation_id,
              language: res.language,
              title: res.title,
              slide_count: res.slide_count,
              native_pptx_file: res.pptx_path,
              pptx_size_mb: res.pptx_size_mb
            },
            null,
            2
          )
        }
      ]
    };
  }

  throw new Error(`Unknown tool: ${name}`);
}

// JSON-RPC 2.0 over stdio (supports both newline-delimited JSON and Content-Length framed MCP)
let inputBuffer = Buffer.alloc(0);
let useContentLengthFraming = false;

function sendRpcResponse(msg) {
  const json = JSON.stringify(msg);
  if (useContentLengthFraming) {
    const byteLen = Buffer.byteLength(json, 'utf8');
    process.stdout.write(`Content-Length: ${byteLen}\r\n\r\n${json}`);
  } else {
    process.stdout.write(`${json}\n`);
  }
}

function handleRpcMessage(msg) {
  if (!msg || typeof msg !== 'object') return;
  const { id, method, params } = msg;

  try {
    if (method === 'initialize') {
      sendRpcResponse({
        jsonrpc: '2.0',
        id,
        result: {
          protocolVersion: (params && params.protocolVersion) || '2024-11-05',
          capabilities: {
            tools: {},
            resources: {}
          },
          serverInfo: {
            name: 'rcmc-presentation-mcp',
            version: '1.0.0'
          }
        }
      });
    } else if (method === 'notifications/initialized') {
      // No response needed for notification
    } else if (method === 'tools/list') {
      sendRpcResponse({
        jsonrpc: '2.0',
        id,
        result: { tools: TOOLS }
      });
    } else if (method === 'tools/call') {
      const result = handleToolCall(params.name, params.arguments || {});
      sendRpcResponse({
        jsonrpc: '2.0',
        id,
        result
      });
    } else if (method === 'resources/list') {
      const resources = [];
      for (const [presId, spec] of activePresentations.entries()) {
        resources.push({
          uri: `ui://rcmc/canvas/${presId}`,
          name: `${spec.title} (RCMC Canvas)`,
          mimeType: 'text/html',
          description: `Interactive RCMC Canvas presentation (${spec.language})`
        });
      }
      sendRpcResponse({
        jsonrpc: '2.0',
        id,
        result: { resources }
      });
    } else if (method === 'resources/read') {
      const uri = (params && params.uri) || '';
      const presId = uri.replace('ui://rcmc/canvas/', '');
      const htmlPath = path.join(OUTPUT_DIR, `${presId}_canvas.html`);
      if (fs.existsSync(htmlPath)) {
        const html = fs.readFileSync(htmlPath, 'utf8');
        sendRpcResponse({
          jsonrpc: '2.0',
          id,
          result: {
            contents: [{ uri, mimeType: 'text/html', text: html }]
          }
        });
      } else {
        throw new Error(`Resource not found: ${uri}`);
      }
    } else if (id !== undefined) {
      sendRpcResponse({
        jsonrpc: '2.0',
        id,
        error: { code: -32601, message: `Method not found: ${method}` }
      });
    }
  } catch (err) {
    if (id !== undefined) {
      sendRpcResponse({
        jsonrpc: '2.0',
        id,
        error: { code: -32000, message: err.message }
      });
    }
  }
}

if (require.main === module) {
  process.stdin.on('data', chunk => {
    inputBuffer = Buffer.concat([inputBuffer, chunk]);
    while (inputBuffer.length > 0) {
      const str = inputBuffer.toString('utf8');
      if (str.startsWith('Content-Length:')) {
        useContentLengthFraming = true;
        const headerEnd = inputBuffer.indexOf('\r\n\r\n');
        if (headerEnd === -1) break;
        const headerStr = inputBuffer.slice(0, headerEnd).toString('utf8');
        const match = headerStr.match(/Content-Length:\s*(\d+)/i);
        if (!match) break;
        const contentLen = parseInt(match[1], 10);
        const totalLen = headerEnd + 4 + contentLen;
        if (inputBuffer.length < totalLen) break;
        const bodyBuf = inputBuffer.slice(headerEnd + 4, totalLen);
        inputBuffer = inputBuffer.slice(totalLen);
        try {
          handleRpcMessage(JSON.parse(bodyBuf.toString('utf8')));
        } catch (e) {}
      } else {
        const nlIndex = inputBuffer.indexOf('\n');
        if (nlIndex === -1) break;
        const line = inputBuffer.slice(0, nlIndex).toString('utf8').trim();
        inputBuffer = inputBuffer.slice(nlIndex + 1);
        if (line) {
          try {
            handleRpcMessage(JSON.parse(line));
          } catch (e) {}
        }
      }
    }
  });
}

module.exports = { buildPresentationFiles, handleToolCall, TOOLS };
