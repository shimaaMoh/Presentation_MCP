const readline = require('readline');
const { handleToolCall, TOOLS } = require('./mcp_server');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('====================================================');
console.log('   🏛️  RCMC Presentation MCP - VS Code Test CLI');
console.log('====================================================');
console.log('1. List RCMC Layouts');
console.log('2. Search Media Library (Photos & Icons)');
console.log('3. Generate Arabic (AR) Sample Presentation');
console.log('4. Generate English (EN) Sample Presentation');
console.log('5. Exit');
console.log('----------------------------------------------------');

function prompt() {
  rl.question('Select an option (1-5): ', (ans) => {
    switch (ans.trim()) {
      case '1': {
        const res = handleToolCall('list_rcmc_layouts', {});
        console.log(res.content[0].text);
        prompt();
        break;
      }
      case '2': {
        rl.question('Enter search keyword (e.g., haram, bus, arafat, kpi): ', (q) => {
          const res = handleToolCall('search_rcmc_media_library', { query: q });
          console.log(res.content[0].text);
          prompt();
        });
        break;
      }
      case '3': {
        console.log('\n⏳ Generating Arabic Presentation...');
        require('./test_generate');
        console.log('✅ Generated Arabic & English sample decks in ./output/');
        prompt();
        break;
      }
      case '4': {
        console.log('\n⏳ Generating English Presentation...');
        require('./test_generate');
        console.log('✅ Generated Arabic & English sample decks in ./output/');
        prompt();
        break;
      }
      case '5':
        rl.close();
        break;
      default:
        console.log('Invalid option.');
        prompt();
    }
  });
}

prompt();
