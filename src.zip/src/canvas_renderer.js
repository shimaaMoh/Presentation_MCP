const fs = require('fs');
const path = require('path');

function loadAsBase64(filePath, mimeType) {
  if (!fs.existsSync(filePath)) return '';
  const buf = fs.readFileSync(filePath);
  return `data:${mimeType};base64,${buf.toString('base64')}`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderCanvasHtml(spec, rootDir) {
  const isAr = !spec.language || spec.language.toUpperCase() === 'AR';
  const dir = isAr ? 'rtl' : 'ltr';
  const langCode = isAr ? 'ar' : 'en';

  // Load fonts as base64 so the HTML canvas renders identical to PowerPoint everywhere
  const fontBook = loadAsBase64(path.join(rootDir, 'assets/fonts/SuisseIntl-Book.otf'), 'font/otf');
  const fontRegular = loadAsBase64(path.join(rootDir, 'assets/fonts/SuisseIntl-Regular.otf'), 'font/otf');
  const fontSemibold = loadAsBase64(path.join(rootDir, 'assets/fonts/SuisseIntl-Semibold.otf'), 'font/otf');
  const fontBold = loadAsBase64(path.join(rootDir, 'assets/fonts/SuisseIntl-Bold.otf'), 'font/otf');

  // Brand SVGs
  const logoWhiteGold = loadAsBase64(path.join(rootDir, 'assets/brand/image1.svg'), 'image/svg+xml');
  const archPatternGold = loadAsBase64(path.join(rootDir, 'assets/brand/image2.svg'), 'image/svg+xml');
  const logoGreenGold = loadAsBase64(path.join(rootDir, 'assets/brand/image8.svg'), 'image/svg+xml');

  // Helper to get photo base64 from HD optimized image, falling back to original or thumb
  function getPhotoUrl(photoId) {
    const numMatch = String(photoId || 'photo_01').match(/(\d+)/);
    const num = numMatch ? numMatch[1].padStart(2, '0') : '01';
    const hdPath = path.join(rootDir, `assets/media/hd/hd_${num}.jpg`);
    if (fs.existsSync(hdPath)) {
      return loadAsBase64(hdPath, 'image/jpeg');
    }
    const thumbPath = path.join(rootDir, `assets/media/ar/thumb_${num}.jpg`);
    return loadAsBase64(thumbPath, 'image/jpeg');
  }

  // Helper to get icon SVG base64
  function getIconUrl(iconId, idxFallback = 1) {
    const numMatch = String(iconId || '').match(/(\d+)/);
    const num = numMatch ? parseInt(numMatch[1], 10) : idxFallback;
    const clamped = Math.max(1, Math.min(18, num));
    const numStr = String(clamped).padStart(2, '0');
    const files = fs.readdirSync(path.join(rootDir, 'assets/icons/ar'));
    const match = files.find(f => f.startsWith(`icon_${numStr}_`));
    if (match) {
      return loadAsBase64(path.join(rootDir, 'assets/icons/ar', match), 'image/svg+xml');
    }
    return '';
  }

  const slidesHtml = (spec.slides || []).map((s, idx) => {
    const slideNum = idx + 1;
    const lid = s.layout_id || 'content_split_photo';
    const title = escapeHtml(s.title || '');
    const subtitle = escapeHtml(s.subtitle || '');
    const heading = escapeHtml(s.heading || '');
    const body = escapeHtml(s.body || '').replace(/\n/g, '<br/>');
    const dept = escapeHtml(s.department || (isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Strategy & Operations'));
    const date = escapeHtml(s.date || (isAr ? 'نوفمبر ٢٠٢٦ م' : 'November 2026'));
    const conf = escapeHtml(s.confidentiality || (isAr ? 'سري وغير قابل للتداول' : 'Confidential and non-negotiable'));
    const items = Array.isArray(s.items) ? s.items : [];
    const metrics = Array.isArray(s.metrics) ? s.metrics : items;

    let inner = '';

    if (lid === 'cover_green_arch' || lid === 'cover_photo_arch' || lid === 'cover_split_photo') {
      const hasPhoto = lid !== 'cover_green_arch';
      const photoSrc = hasPhoto ? getPhotoUrl(s.photo_id || 'photo_01') : '';
      inner = `
        <div class="slide-canvas cover-slide ${lid}">
          <div class="cover-bg-pattern" style="background-image: url('${archPatternGold}')"></div>
          ${hasPhoto ? `<div class="cover-photo-arch"><img src="${photoSrc}" alt="Cover" /></div>` : ''}
          <div class="cover-top-bar">
            <img class="brand-logo" src="${logoWhiteGold}" alt="RCMC" />
          </div>
          <div class="cover-content">
            <div class="cover-subtitle">${subtitle}</div>
            <h1 class="cover-title">${title}</h1>
          </div>
          <div class="cover-footer">
            <span>${dept}</span>
            <span class="dot">•</span>
            <span>${date}</span>
            <span class="dot">•</span>
            <span class="conf-badge">${conf}</span>
          </div>
        </div>`;
    } else if (lid.startsWith('section_')) {
      const isSand = lid === 'section_sand_gold';
      const hasPhoto = lid === 'section_photo_banner';
      const photoSrc = hasPhoto ? getPhotoUrl(s.photo_id || 'photo_02') : '';
      inner = `
        <div class="slide-canvas section-slide ${isSand ? 'sand-theme' : 'emerald-theme'}">
          <div class="cover-bg-pattern" style="background-image: url('${archPatternGold}')"></div>
          ${hasPhoto ? `<div class="section-photo-strip"><img src="${photoSrc}" alt="Section" /></div>` : ''}
          <div class="cover-top-bar">
            <img class="brand-logo" src="${logoWhiteGold}" alt="RCMC" />
          </div>
          <div class="section-center">
            <div class="section-num">${String(slideNum).padStart(2, '0')}</div>
            <h1 class="section-title">${title}</h1>
            <div class="section-subtitle">${subtitle}</div>
          </div>
        </div>`;
    } else if (lid === 'closing_thank_you') {
      inner = `
        <div class="slide-canvas cover-slide closing-slide">
          <div class="cover-bg-pattern" style="background-image: url('${archPatternGold}')"></div>
          <div class="cover-top-bar">
            <img class="brand-logo" src="${logoWhiteGold}" alt="RCMC" />
          </div>
          <div class="closing-center">
            <h1 class="closing-title">${title || (isAr ? 'شكرًا لكم' : 'Thank You')}</h1>
            <p class="closing-sub">${subtitle || (isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'Royal Commission for Makkah City and Holy Sites')}</p>
          </div>
        </div>`;
    } else if (lid === 'content_split_photo' || lid === 'content_two_photos' || lid === 'highlight_banner_photo') {
      const photoSrc = getPhotoUrl(s.photo_id || 'photo_07');
      inner = `
        <div class="slide-canvas standard-slide">
          <div class="slide-header">
            <div class="header-titles">
              <div class="slide-eyebrow">${subtitle}</div>
              <h2 class="slide-main-title">${title}</h2>
            </div>
            <img class="header-logo" src="${logoGreenGold}" alt="RCMC" />
          </div>
          <div class="split-body ${lid === 'highlight_banner_photo' ? 'banner-mode' : ''}">
            <div class="split-text-card">
              <div class="arch-accent-bar"></div>
              ${heading ? `<h3 class="card-heading">${heading}</h3>` : ''}
              <div class="card-body-text">${body}</div>
            </div>
            <div class="split-photo-frame">
              <img src="${photoSrc}" alt="Slide Visual" />
            </div>
          </div>
          <div class="slide-footer-bar">
            <span class="footer-org">${isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Official Presentation'}</span>
            <span class="slide-num-badge">${slideNum}</span>
          </div>
        </div>`;
    } else if (lid === 'three_pillars_icons' || lid === 'three_cards_with_photo') {
      const hasPhoto = lid === 'three_cards_with_photo';
      const photoSrc = hasPhoto ? getPhotoUrl(s.photo_id || 'photo_08') : '';
      const cardsHtml = items.slice(0, 3).map((it, i) => {
        const icSrc = getIconUrl(it.icon_id, i + 1);
        return `
          <div class="pillar-card">
            <div class="pillar-top">
              ${!hasPhoto && icSrc ? `<img class="pillar-icon" src="${icSrc}" alt="icon" />` : `<span class="pillar-num">0${i + 1}</span>`}
              <h3 class="pillar-title">${escapeHtml(it.heading || '')}</h3>
            </div>
            <p class="pillar-desc">${escapeHtml(it.body || '')}</p>
          </div>`;
      }).join('');
      inner = `
        <div class="slide-canvas standard-slide">
          <div class="slide-header">
            <div class="header-titles">
              <div class="slide-eyebrow">${subtitle}</div>
              <h2 class="slide-main-title">${title}</h2>
            </div>
            <img class="header-logo" src="${logoGreenGold}" alt="RCMC" />
          </div>
          <div class="pillars-layout ${hasPhoto ? 'with-side-photo' : ''}">
            <div class="pillars-grid">${cardsHtml}</div>
            ${hasPhoto ? `<div class="side-arched-photo"><img src="${photoSrc}" alt="Visual" /></div>` : ''}
          </div>
          <div class="slide-footer-bar">
            <span class="footer-org">${isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Official Presentation'}</span>
            <span class="slide-num-badge">${slideNum}</span>
          </div>
        </div>`;
    } else if (lid === 'agenda_four_items' || lid === 'three_rows_icons_photo') {
      const photoSrc = getPhotoUrl(s.photo_id || 'photo_10');
      const maxCount = lid === 'agenda_four_items' ? 4 : 3;
      const rowsHtml = items.slice(0, maxCount).map((it, i) => {
        const numStr = escapeHtml(it.number || `0${i + 1}`);
        const icSrc = lid === 'three_rows_icons_photo' ? getIconUrl(it.icon_id, i + 3) : '';
        return `
          <div class="agenda-row">
            <div class="agenda-badge">
              ${icSrc ? `<img class="row-icon" src="${icSrc}" alt="icon" />` : `<span>${numStr}</span>`}
            </div>
            <div class="agenda-text">
              <h4>${escapeHtml(it.heading || '')}</h4>
              <p>${escapeHtml(it.body || '')}</p>
            </div>
          </div>`;
      }).join('');
      inner = `
        <div class="slide-canvas standard-slide">
          <div class="slide-header">
            <div class="header-titles">
              <div class="slide-eyebrow">${subtitle}</div>
              <h2 class="slide-main-title">${title}</h2>
            </div>
            <img class="header-logo" src="${logoGreenGold}" alt="RCMC" />
          </div>
          <div class="agenda-split">
            <div class="agenda-list">${rowsHtml}</div>
            <div class="side-arched-photo"><img src="${photoSrc}" alt="Agenda Photo" /></div>
          </div>
          <div class="slide-footer-bar">
            <span class="footer-org">${isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Official Presentation'}</span>
            <span class="slide-num-badge">${slideNum}</span>
          </div>
        </div>`;
    } else if (lid === 'kpi_metrics_chart' || lid === 'four_grid_infographic') {
      const isFour = lid === 'four_grid_infographic';
      const list = (isFour ? items : metrics).slice(0, isFour ? 4 : 3);
      const kpiHtml = list.map((m, i) => {
        const val = escapeHtml(m.value || m.number || m.heading || `0${i + 1}`);
        const head = escapeHtml(m.heading || '');
        const desc = escapeHtml(m.description || m.body || '');
        return `
          <div class="kpi-card">
            <div class="kpi-ring"><span>${val}</span></div>
            <div class="kpi-info">
              ${isFour && head ? `<h4>${head}</h4>` : ''}
              <p>${desc}</p>
            </div>
          </div>`;
      }).join('');
      inner = `
        <div class="slide-canvas standard-slide">
          <div class="slide-header">
            <div class="header-titles">
              <div class="slide-eyebrow">${subtitle}</div>
              <h2 class="slide-main-title">${title}</h2>
            </div>
            <img class="header-logo" src="${logoGreenGold}" alt="RCMC" />
          </div>
          <div class="kpi-grid ${isFour ? 'four-quad' : 'three-metrics'}">${kpiHtml}</div>
          <div class="slide-footer-bar">
            <span class="footer-org">${isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Official Presentation'}</span>
            <span class="slide-num-badge">${slideNum}</span>
          </div>
        </div>`;
    } else if (lid === 'timeline_three_horizons' || lid === 'process_four_stages') {
      const maxSt = lid === 'process_four_stages' ? 4 : 3;
      const stepsHtml = items.slice(0, maxSt).map((st, i) => {
        const h = escapeHtml(st.horizon || st.stage_name || st.heading || `0${i + 1}`);
        const d = escapeHtml(st.duration || st.number || '');
        const b = escapeHtml(st.body || '');
        return `
          <div class="timeline-step">
            <div class="step-header">
              <span class="step-index">0${i + 1}</span>
              <div class="step-titles">
                <h4>${h}</h4>
                ${d ? `<span class="step-duration">${d}</span>` : ''}
              </div>
            </div>
            <p class="step-body">${b}</p>
          </div>`;
      }).join('');
      inner = `
        <div class="slide-canvas standard-slide">
          <div class="slide-header">
            <div class="header-titles">
              <div class="slide-eyebrow">${subtitle}</div>
              <h2 class="slide-main-title">${title}</h2>
            </div>
            <img class="header-logo" src="${logoGreenGold}" alt="RCMC" />
          </div>
          <div class="timeline-track cols-${maxSt}">${stepsHtml}</div>
          <div class="slide-footer-bar">
            <span class="footer-org">${isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Official Presentation'}</span>
            <span class="slide-num-badge">${slideNum}</span>
          </div>
        </div>`;
    } else if (lid === 'data_table_slide') {
      const headers = Array.isArray(s.table_headers) ? s.table_headers : [];
      const rows = Array.isArray(s.table_rows) ? s.table_rows : [];
      const thHtml = headers.map(h => `<th>${escapeHtml(h)}</th>`).join('');
      const trHtml = rows.map(r => `<tr>${(Array.isArray(r) ? r : []).map(c => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('');
      inner = `
        <div class="slide-canvas standard-slide">
          <div class="slide-header">
            <div class="header-titles">
              <div class="slide-eyebrow">${subtitle}</div>
              <h2 class="slide-main-title">${title}</h2>
            </div>
            <img class="header-logo" src="${logoGreenGold}" alt="RCMC" />
          </div>
          <div class="table-layout">
            ${heading || body ? `<div class="table-side-summary"><h3>${heading}</h3><p>${body}</p></div>` : ''}
            <div class="table-wrapper">
              <table class="rcmc-table">
                ${thHtml ? `<thead><tr>${thHtml}</tr></thead>` : ''}
                <tbody>${trHtml}</tbody>
              </table>
            </div>
          </div>
          <div class="slide-footer-bar">
            <span class="footer-org">${isAr ? 'الهيئة الملكية لمدينة مكة المكرمة والمشاعر المقدسة' : 'RCMC Official Presentation'}</span>
            <span class="slide-num-badge">${slideNum}</span>
          </div>
        </div>`;
    }

    return `<section class="slide-frame ${idx === 0 ? 'active' : ''}" data-index="${idx}" data-title="${title}">${inner}</section>`;
  }).join('\n');

  const thumbsNav = (spec.slides || []).map((s, idx) => `
    <button class="thumb-item ${idx === 0 ? 'active' : ''}" onclick="goToSlide(${idx})">
      <span class="thumb-num">${String(idx + 1).padStart(2, '0')}</span>
      <span class="thumb-label">${escapeHtml(s.title || s.layout_id)}</span>
    </button>
  `).join('');

  return `<!DOCTYPE html>
<html lang="${langCode}" dir="${dir}">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${escapeHtml(spec.title || 'RCMC Presentation')}</title>
<style>
  @font-face { font-family: 'Suisse Intl'; src: url('${fontBook}') format('opentype'); font-weight: 300; }
  @font-face { font-family: 'Suisse Intl'; src: url('${fontRegular}') format('opentype'); font-weight: 400; }
  @font-face { font-family: 'Suisse Intl'; src: url('${fontSemibold}') format('opentype'); font-weight: 600; }
  @font-face { font-family: 'Suisse Intl'; src: url('${fontBold}') format('opentype'); font-weight: 700; }

  :root {
    --rcmc-green: #016A40;
    --rcmc-emerald: #005242;
    --rcmc-gold: #C2AB78;
    --rcmc-bronze: #9E8061;
    --rcmc-terracotta: #82331A;
    --rcmc-cream: #F6F4EE;
    --rcmc-sand-bg: #EFECE4;
    --rcmc-dark: #121816;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Suisse Intl', 'Segoe UI', Tahoma, sans-serif;
    background: #0b1311;
    color: #fff;
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  /* Top Gemini Canvas Toolbar */
  .canvas-toolbar {
    height: 54px;
    background: #101c19;
    border-bottom: 1px solid rgba(194, 171, 120, 0.25);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px;
    direction: ltr;
  }
  .toolbar-left { display: flex; align-items: center; gap: 12px; }
  .rcmc-badge {
    background: var(--rcmc-green);
    color: var(--rcmc-gold);
    font-weight: 700;
    font-size: 11px;
    letter-spacing: 0.8px;
    padding: 4px 10px;
    border-radius: 4px;
    border: 1px solid var(--rcmc-gold);
  }
  .deck-title { font-size: 14px; font-weight: 600; color: #f0ede6; }
  .toolbar-controls { display: flex; align-items: center; gap: 10px; }
  .nav-btn {
    background: rgba(255,255,255,0.07);
    color: #fff;
    border: 1px solid rgba(194,171,120,0.3);
    padding: 6px 13px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    font-family: inherit;
    transition: all 0.15s;
  }
  .nav-btn:hover { background: var(--rcmc-green); border-color: var(--rcmc-gold); }
  .pptx-pill {
    background: linear-gradient(135deg, var(--rcmc-gold), var(--rcmc-bronze));
    color: #0b1311;
    font-weight: 700;
    padding: 6px 14px;
    border-radius: 6px;
    font-size: 12px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  /* Main Workspace */
  .canvas-workspace {
    flex: 1;
    display: flex;
    overflow: hidden;
  }

  /* Slide Filmstrip Sidebar */
  .filmstrip {
    width: 230px;
    background: #0e1815;
    border-inline-end: 1px solid rgba(194,171,120,0.18);
    overflow-y: auto;
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .thumb-item {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    text-align: start;
    background: rgba(255,255,255,0.03);
    border: 1px solid transparent;
    padding: 9px 10px;
    border-radius: 6px;
    color: #b8c2be;
    cursor: pointer;
    font-family: inherit;
    font-size: 12px;
    transition: all 0.15s;
  }
  .thumb-item:hover { background: rgba(1, 106, 64, 0.25); color: #fff; }
  .thumb-item.active {
    background: rgba(1, 106, 64, 0.45);
    border-color: var(--rcmc-gold);
    color: #fff;
  }
  .thumb-num {
    font-weight: 700;
    color: var(--rcmc-gold);
    font-size: 11px;
    min-width: 22px;
  }
  .thumb-label {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Stage Container */
  .stage-area {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background: radial-gradient(circle at center, #182924 0%, #09100e 100%);
    overflow: auto;
  }

  /* 16:9 Slide Aspect Ratio Box */
  .slide-frame {
    display: none;
    width: min(100%, calc((100vh - 110px) * 16 / 9));
    aspect-ratio: 16 / 9;
    box-shadow: 0 25px 60px rgba(0,0,0,0.65), 0 0 0 1px rgba(194,171,120,0.3);
    border-radius: 6px;
    overflow: hidden;
    position: relative;
  }
  .slide-frame.active { display: block; }

  .slide-canvas {
    width: 100%;
    height: 100%;
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden;
  }

  /* Cover & Section Slides */
  .cover-slide, .section-slide {
    background: linear-gradient(135deg, var(--rcmc-emerald) 0%, var(--rcmc-green) 100%);
    color: #fff;
    padding: 4.5% 5.5%;
  }
  .section-slide.sand-theme {
    background: linear-gradient(135deg, #b89f6d 0%, #9E8061 100%);
  }
  .cover-bg-pattern {
    position: absolute;
    inset: 0;
    background-size: cover;
    background-position: center;
    opacity: 0.22;
    pointer-events: none;
  }
  .cover-photo-arch {
    position: absolute;
    top: 8%;
    bottom: 12%;
    inset-inline-end: 5.5%;
    width: 38%;
    border-radius: 220px 220px 16px 16px;
    overflow: hidden;
    border: 3px solid var(--rcmc-gold);
    box-shadow: 0 15px 35px rgba(0,0,0,0.4);
    z-index: 1;
  }
  .cover-photo-arch img { width: 100%; height: 100%; object-fit: cover; }
  .cover-top-bar { position: relative; z-index: 2; display: flex; justify-content: space-between; }
  .brand-logo { height: 48px; width: auto; }
  .cover-content {
    position: relative;
    z-index: 2;
    max-width: 68%;
    margin-top: auto;
    margin-bottom: 4%;
  }
  .cover-subtitle {
    color: var(--rcmc-gold);
    font-size: clamp(14px, 1.5vw, 22px);
    font-weight: 600;
    margin-bottom: 10px;
  }
  .cover-title {
    font-size: clamp(24px, 2.8vw, 44px);
    font-weight: 700;
    line-height: 1.25;
  }
  .cover-footer {
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: clamp(11px, 1vw, 14px);
    color: rgba(255,255,255,0.85);
    border-top: 1px solid rgba(194,171,120,0.35);
    padding-top: 12px;
  }
  .conf-badge {
    background: rgba(0,0,0,0.25);
    color: var(--rcmc-gold);
    padding: 3px 10px;
    border-radius: 4px;
  }

  /* Section Center */
  .section-center {
    position: relative;
    z-index: 2;
    margin: auto 0;
    max-width: 75%;
  }
  .section-num {
    font-size: clamp(28px, 3.5vw, 54px);
    font-weight: 700;
    color: var(--rcmc-gold);
    opacity: 0.85;
    margin-bottom: 6px;
  }
  .section-title { font-size: clamp(26px, 3vw, 46px); font-weight: 700; margin-bottom: 10px; }
  .section-subtitle { font-size: clamp(15px, 1.5vw, 22px); color: rgba(255,255,255,0.88); }
  .section-photo-strip {
    position: absolute;
    top: 0; bottom: 0;
    inset-inline-end: 0;
    width: 35%;
    z-index: 1;
  }
  .section-photo-strip img { width: 100%; height: 100%; object-fit: cover; }

  /* Standard Content Slides */
  .standard-slide {
    background: var(--rcmc-cream);
    color: var(--rcmc-dark);
    padding: 3.5% 5%;
  }
  .slide-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    border-bottom: 2px solid var(--rcmc-gold);
    padding-bottom: 1.5%;
    margin-bottom: 2.2%;
  }
  .slide-eyebrow {
    color: var(--rcmc-bronze);
    font-size: clamp(11px, 1.05vw, 15px);
    font-weight: 600;
    margin-bottom: 3px;
  }
  .slide-main-title {
    color: var(--rcmc-green);
    font-size: clamp(18px, 2vw, 30px);
    font-weight: 700;
  }
  .header-logo { height: 38px; width: auto; }

  /* Split Content + Photo */
  .split-body {
    flex: 1;
    display: grid;
    grid-template-columns: 1.25fr 0.95fr;
    gap: 3.5%;
    align-items: center;
    overflow: hidden;
  }
  .split-text-card {
    background: #fff;
    padding: 5% 6%;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.05);
    border-inline-start: 5px solid var(--rcmc-green);
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .card-heading {
    color: var(--rcmc-emerald);
    font-size: clamp(15px, 1.4vw, 21px);
    margin-bottom: 12px;
  }
  .card-body-text {
    color: #333c39;
    font-size: clamp(12px, 1.15vw, 17px);
    line-height: 1.65;
  }
  .split-photo-frame {
    height: 100%;
    border-radius: 160px 160px 12px 12px;
    overflow: hidden;
    border: 3px solid var(--rcmc-gold);
  }
  .split-photo-frame img { width: 100%; height: 100%; object-fit: cover; }

  /* 3 Pillars */
  .pillars-layout { flex: 1; display: flex; gap: 3%; overflow: hidden; }
  .pillars-grid {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 2.5%;
  }
  .pillar-card {
    background: #fff;
    border-radius: 12px;
    padding: 6%;
    border-top: 4px solid var(--rcmc-green);
    box-shadow: 0 6px 20px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .pillar-icon { width: 42px; height: 42px; margin-bottom: 6px; }
  .pillar-num {
    display: inline-block;
    font-size: 22px;
    font-weight: 700;
    color: var(--rcmc-gold);
  }
  .pillar-title { color: var(--rcmc-green); font-size: clamp(14px, 1.25vw, 19px); }
  .pillar-desc { color: #444; font-size: clamp(11px, 1vw, 15px); line-height: 1.55; }
  .side-arched-photo {
    width: 26%;
    height: 100%;
    border-radius: 140px 140px 12px 12px;
    overflow: hidden;
    border: 2px solid var(--rcmc-gold);
  }
  .side-arched-photo img { width: 100%; height: 100%; object-fit: cover; }

  /* Agenda / Feature Rows */
  .agenda-split { flex: 1; display: flex; gap: 3.5%; overflow: hidden; }
  .agenda-list {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    gap: 10px;
  }
  .agenda-row {
    background: #fff;
    border-radius: 10px;
    padding: 2.2% 3.5%;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 4px 14px rgba(0,0,0,0.04);
    border-inline-start: 4px solid var(--rcmc-gold);
  }
  .agenda-badge {
    width: 44px;
    height: 44px;
    min-width: 44px;
    min-height: 44px;
    flex-shrink: 0;
    aspect-ratio: 1 / 1;
    border-radius: 50%;
    background: var(--rcmc-sand-bg);
    color: var(--rcmc-green);
    font-weight: 700;
    font-size: 16px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }
  .row-icon { width: 26px; height: 26px; flex-shrink: 0; }
  .agenda-text h4 { color: var(--rcmc-green); font-size: clamp(13px, 1.15vw, 17px); margin-bottom: 3px; }
  .agenda-text p { color: #4a5450; font-size: clamp(11px, 0.95vw, 14px); line-height: 1.45; }

  /* KPIs & 4-Grid */
  .kpi-grid {
    flex: 1;
    display: grid;
    gap: 2.5%;
    align-items: stretch;
  }
  .kpi-grid.three-metrics { grid-template-columns: repeat(3, 1fr); }
  .kpi-grid.four-quad { grid-template-columns: repeat(2, 1fr); grid-template-rows: repeat(2, 1fr); }
  .kpi-card {
    background: #fff;
    border-radius: 12px;
    padding: 4% 5%;
    display: flex;
    align-items: center;
    gap: 18px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.05);
    border-bottom: 4px solid var(--rcmc-gold);
    overflow: hidden;
  }
  .kpi-ring {
    width: clamp(66px, 6vw, 84px);
    height: clamp(66px, 6vw, 84px);
    min-width: clamp(66px, 6vw, 84px);
    min-height: clamp(66px, 6vw, 84px);
    flex-shrink: 0;
    aspect-ratio: 1 / 1;
    border-radius: 50%;
    border: 5px solid var(--rcmc-green);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    font-weight: 700;
    font-size: clamp(13px, 1.3vw, 22px);
    color: var(--rcmc-green);
    background: var(--rcmc-sand-bg);
    box-sizing: border-box;
    overflow: hidden;
    padding: 2px;
  }
  .kpi-info h4 { color: var(--rcmc-emerald); font-size: clamp(13px, 1.15vw, 17px); margin-bottom: 4px; }
  .kpi-info p { color: #444; font-size: clamp(11px, 1vw, 14.5px); line-height: 1.5; }

  /* Timeline / Stages */
  .timeline-track {
    flex: 1;
    display: grid;
    gap: 2.2%;
    align-items: stretch;
  }
  .timeline-track.cols-3 { grid-template-columns: repeat(3, 1fr); }
  .timeline-track.cols-4 { grid-template-columns: repeat(4, 1fr); }
  .timeline-step {
    background: #fff;
    border-radius: 12px;
    padding: 5%;
    border-top: 5px solid var(--rcmc-emerald);
    box-shadow: 0 6px 18px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .step-header { display: flex; align-items: center; gap: 10px; }
  .step-index {
    background: var(--rcmc-green);
    color: var(--rcmc-gold);
    font-weight: 700;
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 14px;
  }
  .step-titles h4 { color: var(--rcmc-green); font-size: clamp(13px, 1.15vw, 17px); }
  .step-duration {
    display: inline-block;
    font-size: 11px;
    color: var(--rcmc-bronze);
    font-weight: 600;
  }
  .step-body { color: #444; font-size: clamp(11px, 0.98vw, 14.5px); line-height: 1.55; }

  /* Data Table Slide */
  .table-layout { flex: 1; display: flex; gap: 3%; overflow: hidden; }
  .table-side-summary {
    width: 28%;
    background: var(--rcmc-emerald);
    color: #fff;
    padding: 3.5%;
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .table-side-summary h3 { color: var(--rcmc-gold); margin-bottom: 10px; font-size: clamp(14px, 1.3vw, 20px); }
  .table-side-summary p { font-size: clamp(11px, 1vw, 14.5px); line-height: 1.6; color: rgba(255,255,255,0.9); }
  .table-wrapper { flex: 1; overflow: auto; background: #fff; border-radius: 12px; box-shadow: 0 6px 18px rgba(0,0,0,0.05); }
  .rcmc-table { width: 100%; border-collapse: collapse; font-size: clamp(11px, 1vw, 14px); }
  .rcmc-table th {
    background: var(--rcmc-green);
    color: #fff;
    padding: 12px 14px;
    text-align: start;
    font-weight: 600;
  }
  .rcmc-table td { padding: 10px 14px; border-bottom: 1px solid #eee; color: #2b3330; }
  .rcmc-table tr:nth-child(even) td { background: #f9f8f4; }

  /* Footer Bar */
  .slide-footer-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 1%;
    border-top: 1px solid rgba(158, 128, 97, 0.25);
    font-size: 11px;
    color: var(--rcmc-bronze);
  }
  .slide-num-badge {
    background: var(--rcmc-green);
    color: #fff;
    font-weight: 700;
    padding: 2px 9px;
    border-radius: 4px;
  }

  /* Closing */
  .closing-center { margin: auto; text-align: center; position: relative; z-index: 2; }
  .closing-title { font-size: clamp(34px, 4vw, 64px); color: var(--rcmc-gold); margin-bottom: 12px; }
  .closing-sub { font-size: clamp(15px, 1.5vw, 22px); color: #fff; }

  @media print {
    * {
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
    @page {
      size: landscape;
      margin: 0;
    }
    html, body {
      background: #fff !important;
      height: auto !important;
      overflow: visible !important;
      margin: 0 !important;
      padding: 0 !important;
    }
    .canvas-toolbar, .filmstrip { display: none !important; }
    .canvas-workspace { display: block !important; height: auto !important; overflow: visible !important; }
    .stage-area { padding: 0 !important; margin: 0 !important; display: block !important; background: transparent !important; overflow: visible !important; height: auto !important; }
    .slide-frame {
      display: block !important;
      width: 100vw !important;
      height: 100vh !important;
      max-width: 100vw !important;
      max-height: 100vh !important;
      aspect-ratio: 16 / 9 !important;
      page-break-after: always !important;
      break-after: page !important;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
      box-shadow: none !important;
      border-radius: 0 !important;
      margin: 0 !important;
      padding: 0 !important;
      position: relative !important;
    }
    .slide-canvas {
      width: 100% !important;
      height: 100% !important;
      display: flex !important;
      position: absolute !important;
      top: 0 !important;
      left: 0 !important;
    }
  }
</style>
</head>
<body>
  <header class="canvas-toolbar">
    <div class="toolbar-left">
      <span class="rcmc-badge">${isAr ? 'عون • العرض التقديمي التفاعلي' : 'AWN INTERACTIVE PRESENTATION'}</span>
      <span class="deck-title">${escapeHtml(spec.title || 'RCMC Presentation')} (${isAr ? 'العربية - RTL' : 'English - LTR'})</span>
    </div>
    <div class="toolbar-controls">
      <button class="nav-btn" onclick="prevSlide()">${isAr ? 'السابق ‹' : '‹ Prev'}</button>
      <span id="slideCounter" style="font-size:12px; min-width:55px; text-align:center;">1 / ${(spec.slides || []).length}</span>
      <button class="nav-btn" onclick="nextSlide()">${isAr ? 'التالي ›' : 'Next ›'}</button>
      <button class="nav-btn" onclick="toggleFullscreen()">${isAr ? '⛶ ملء الشاشة' : '⛶ Fullscreen'}</button>
      <button class="nav-btn" onclick="window.print()">${isAr ? '🖨️ طباعة / PDF' : '🖨️ Print / PDF'}</button>
      ${spec.output_pptx ? `<a class="pptx-pill" href="file:///${spec.output_pptx.replace(/\\/g, '/')}" download>${isAr ? '📥 تحميل العرض بقالب الهيئة الملكية الرسمي (.pptx)' : '📥 Download the presentation in RCMC\'s official template (.pptx)'}</a>` : ''}
    </div>
  </header>

  <div class="canvas-workspace">
    <aside class="filmstrip">${thumbsNav}</aside>
    <main class="stage-area" id="stageArea">${slidesHtml}</main>
  </div>

  <script>
    let currentSlide = 0;
    const slides = document.querySelectorAll('.slide-frame');
    const thumbs = document.querySelectorAll('.thumb-item');
    const counter = document.getElementById('slideCounter');

    function goToSlide(n) {
      if (!slides.length) return;
      currentSlide = (n + slides.length) % slides.length;
      slides.forEach((s, i) => s.classList.toggle('active', i === currentSlide));
      thumbs.forEach((t, i) => t.classList.toggle('active', i === currentSlide));
      counter.textContent = (currentSlide + 1) + ' / ' + slides.length;
    }
    function nextSlide() { goToSlide(currentSlide + 1); }
    function prevSlide() { goToSlide(currentSlide - 1); }
    function toggleFullscreen() {
      const el = document.documentElement;
      if (!document.fullscreenElement) el.requestFullscreen();
      else document.exitFullscreen();
    }
    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') nextSlide();
      if (e.key === 'ArrowLeft' || e.key === 'PageUp') prevSlide();
    });
  </script>
</body>
</html>`;
}

module.exports = { renderCanvasHtml };
